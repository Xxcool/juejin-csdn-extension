// src/core/diagnostic.ts
var stageLabels = { validation: "\u5185\u5BB9\u6821\u9A8C", authentication: "\u767B\u5F55\u68C0\u67E5", content: "\u5185\u5BB9\u5904\u7406", images: "\u56FE\u7247\u8F6C\u5B58", draft: "\u8349\u7A3F\u4FDD\u5B58", recovery: "\u4EFB\u52A1\u6062\u590D" };
var categoryLabels = { login: "\u767B\u5F55\u5931\u6548", network: "\u7F51\u7EDC\u5F02\u5E38", "rate-limit": "\u5E73\u53F0\u9650\u6D41", "platform-change": "\u5E73\u53F0\u63A5\u53E3\u5F02\u5E38", content: "\u5185\u5BB9\u5F02\u5E38", blocked: "\u8986\u76D6\u963B\u65AD", interrupted: "\u4EFB\u52A1\u4E2D\u65AD", unknown: "\u672A\u77E5\u5F02\u5E38" };

// src/core/settings.ts
var defaultSettings = {
  autoSyncAfterPublish: true,
  defaultCsdnCategory: "",
  categoryMappings: [],
  syncCover: true,
  autoSummary: true,
  appendSourceLink: true,
  imageFailurePolicy: "continue",
  confirmDraftUpdate: false
};
function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}
function normalizeSettings(value) {
  const input = value && typeof value === "object" ? value : {};
  const mappings = Array.isArray(input.categoryMappings) ? input.categoryMappings.map((item) => ({ sourceTag: clean(item?.sourceTag), targetCategory: clean(item?.targetCategory) })).filter((item) => item.sourceTag && item.targetCategory) : [];
  return {
    autoSyncAfterPublish: input.autoSyncAfterPublish !== false,
    defaultCsdnCategory: clean(input.defaultCsdnCategory),
    categoryMappings: mappings,
    syncCover: input.syncCover !== false,
    autoSummary: input.autoSummary !== false,
    appendSourceLink: input.appendSourceLink !== false,
    imageFailurePolicy: input.imageFailurePolicy === "abort" ? "abort" : "continue",
    confirmDraftUpdate: input.confirmDraftUpdate === true
  };
}
function parseCategoryMappings(value) {
  return value.split(/\r?\n/).map((line) => {
    const separator = line.indexOf("=");
    return separator < 0 ? void 0 : { sourceTag: line.slice(0, separator).trim(), targetCategory: line.slice(separator + 1).trim() };
  }).filter((item) => !!item?.sourceTag && !!item.targetCategory);
}
function formatCategoryMappings(mappings) {
  return mappings.map((item) => `${item.sourceTag} = ${item.targetCategory}`).join("\n");
}

// src/popup.ts
var $ = (selector) => document.querySelector(selector);
var loginStatus = "checking";
var checkSequence = 0;
var historyFilter = "all";
var currentSettings = defaultSettings;
var currentTab = "history";
var labels = {
  saved: "\u540C\u6B65\u6210\u529F",
  failed: "\u540C\u6B65\u5931\u8D25",
  "needs-user": "\u9700\u8981\u5904\u7406",
  "needs-confirmation": "\u7B49\u5F85\u786E\u8BA4",
  queued: "\u7B49\u5F85\u540C\u6B65",
  "checking-login": "\u68C0\u67E5\u767B\u5F55",
  transforming: "\u5904\u7406\u5185\u5BB9",
  writing: "\u4FDD\u5B58\u8349\u7A3F"
};
var toastTimer = 0;
var currentTasksCache = [];
function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => element.classList.remove("show"), 2400);
}
function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll(".tab-button").forEach((button) => {
    const isActive = button.dataset.tab === tab;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-selected", String(isActive));
  });
  const thumb = $("#spring-thumb");
  if (thumb) {
    thumb.style.transform = tab === "settings" ? "translateX(100%)" : "translateX(0)";
  }
  const historyPane = $("#pane-history");
  const settingsPane = $("#pane-settings");
  historyPane.classList.toggle("active", tab === "history");
  settingsPane.classList.toggle("active", tab === "settings");
  historyPane.hidden = tab !== "history";
  settingsPane.hidden = tab !== "settings";
  if (tab === "history") void loadTasks();
  if (tab === "settings") {
    void loadSettings();
    void loadCsdnCategories();
  }
}
async function checkLogin() {
  const current = ++checkSequence;
  const pill = $("#login-state");
  const text = $("#login-text");
  loginStatus = "checking";
  pill.className = "platform-pill checking";
  pill.title = "\u6B63\u5728\u68C0\u6D4B CSDN \u767B\u5F55\u72B6\u6001\u2026";
  text.textContent = "\u68C0\u6D4B\u4E2D\u2026";
  try {
    const result = await Promise.race([
      chrome.runtime.sendMessage({ type: "CHECK_CSDN_STATUS" }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("\u68C0\u6D4B\u8D85\u65F6")), 7e3))
    ]);
    if (current !== checkSequence) return;
    if (result?.loggedIn) {
      loginStatus = "logged-in";
      pill.className = "platform-pill logged";
      pill.title = "CSDN \u5DF2\u767B\u5F55\uFF0C\u70B9\u51FB\u53EF\u5237\u65B0\u72B6\u6001";
      text.textContent = result.account ? `CSDN: ${result.account} \u2713` : "CSDN \u5DF2\u767B\u5F55 \u2713";
    } else if (result?.ok) {
      loginStatus = "logged-out";
      pill.className = "platform-pill login-link";
      pill.title = "CSDN \u672A\u767B\u5F55\uFF0C\u70B9\u51FB\u524D\u5F80\u767B\u5F55";
      text.textContent = "CSDN \u672A\u767B\u5F55 \u2197";
    } else throw new Error(result?.message || "\u68C0\u6D4B\u5931\u8D25");
  } catch (error) {
    if (current !== checkSequence) return;
    loginStatus = "error";
    pill.className = "platform-pill error";
    pill.title = "\u767B\u5F55\u72B6\u6001\u68C0\u6D4B\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5";
    text.textContent = "CSDN \u68C0\u6D4B\u5931\u8D25 \u21BB";
    toast(error.message);
  }
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function formatDate(value) {
  return new Date(value).toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }).replaceAll("/", "-");
}
function formatDuration(durationMs) {
  if (durationMs < 1e3) return `${(durationMs / 1e3).toFixed(1)}s`;
  if (durationMs < 6e4) return `${(durationMs / 1e3).toFixed(1)}s`;
  return `${Math.floor(durationMs / 6e4)}m ${Math.round(durationMs % 6e4 / 1e3)}s`;
}
function statusKind(task) {
  if (task.status === "saved") return task.warnings?.length ? "warning" : "success";
  if (task.status === "failed" || task.status === "needs-user") return "failure";
  if (task.status === "needs-confirmation") return "warning";
  return "working";
}
function taskCard(task) {
  const kind = statusKind(task);
  let stateText = labels[task.status] || "\u540C\u6B65\u4E2D";
  let stateIcon = "\u26F5";
  if (task.status === "saved") {
    stateText = task.warnings?.length ? "\u5DF2\u4FDD\u5B58\uFF0C\u6709\u8B66\u544A" : task.draftUrl ? "\u5DF2\u62B5\u8FBE\u8349\u7A3F\u7BB1" : "\u540C\u6B65\u6210\u529F";
    stateIcon = task.warnings?.length ? "\u26A0" : "\u2713";
  } else if (task.status === "failed") {
    stateText = "\u540C\u6B65\u5931\u8D25";
    stateIcon = "\u2715";
  } else if (task.status === "needs-user") {
    stateText = "\u9700\u8981\u5904\u7406";
    stateIcon = "!";
  } else if (task.status === "needs-confirmation") {
    stateText = "\u7B49\u5F85\u786E\u8BA4";
    stateIcon = "\u26A0";
  }
  const cover = task.article.cover ? `<img src="${escapeHtml(task.article.cover)}" alt="">` : "";
  const actions = [];
  if (task.draftUrl) actions.push(`<button class="history-action btn-action-primary" data-open="${escapeHtml(task.draftUrl)}">\u8349\u7A3F \u2197</button>`);
  if (!["queued", "checking-login", "transforming", "writing"].includes(task.status)) actions.push(`<button class="history-action btn-action-dryrun" data-dryrun="${escapeHtml(task.id)}" title="\u540C\u6B65\u9884\u6F14\uFF1A\u67E5\u770B\u5206\u7C7B\u547D\u4E2D\u3001\u56FE\u7247\u8F6C\u5B58\u4E0E\u5185\u5BB9\u98CE\u9669\uFF0C\u4E0D\u5199\u5165 CSDN">\u9884\u6F14</button>`);
  if (task.status === "needs-confirmation") actions.push(`<button class="history-action confirm btn-action-confirm" data-confirm="${escapeHtml(task.id)}">\u786E\u8BA4\u66F4\u65B0</button>`);
  if (["failed", "needs-user"].includes(task.status)) actions.push(`<button class="history-action retry btn-action-retry" data-retry="${escapeHtml(task.id)}">\u91CD\u8BD5</button>`);
  if (!["queued", "checking-login", "transforming", "writing"].includes(task.status)) actions.push(`<button class="history-action delete btn-action-delete" data-delete="${escapeHtml(task.id)}" title="\u5220\u9664\u672C\u5730\u8BB0\u5F55" aria-label="\u5220\u9664\u672C\u5730\u8BB0\u5F55"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg></button>`);
  const action = `<span class="task-actions">${actions.join("")}</span>`;
  const error = task.error ? `<p class="platform-error" title="${escapeHtml(task.error)}">${escapeHtml(task.error)}</p>` : "";
  const diagText = task.diagnostic ? `${task.article.title} [${task.diagnostic.category} - ${task.diagnostic.stage}]: ${task.diagnostic.message} (${task.diagnostic.suggestion})` : "";
  const diagnostic = task.diagnostic ? `<div class="task-diagnostic"><div class="diagnostic-header"><b>${categoryLabels[task.diagnostic.category]} \xB7 ${stageLabels[task.diagnostic.stage]}</b><button class="btn-copy-diag" data-copy-diag="${escapeHtml(diagText)}">\u590D\u5236\u8BCA\u65AD</button></div><span>${escapeHtml(task.diagnostic.suggestion)}</span></div>` : "";
  const warning = task.warnings?.length ? `<p class="platform-warning" title="${escapeHtml(task.warnings.join("\n"))}">${escapeHtml(task.warnings.join("\uFF1B"))}</p>` : "";
  const stats = task.stats ? `\u8017\u65F6 <b>${formatDuration(task.stats.durationMs)}</b><i>\xB7</i>\u56FE\u7247 <b>${task.stats.imageSucceeded}/${task.stats.imageTotal}</b>${task.stats.imageFailed ? `<i>\xB7</i><strong>${task.stats.imageFailed}</strong> \u5931\u8D25` : ""}` : "";
  const progressPercent = task.progress?.total ? Math.min(100, Math.max(0, Math.round(task.progress.current / task.progress.total * 100))) : 0;
  const progress = task.progress ? `<div class="task-progress-box">
    <div class="progress-info">
      <span class="progress-msg">${escapeHtml(task.progress.message || "\u6B63\u5728\u6446\u6E21\u4E2D\u2026")}</span>
      <span class="progress-percent">${task.progress.total ? `${progressPercent}%` : "\u8FDB\u884C\u4E2D\u2026"}</span>
    </div>
    <div class="task-progress ${task.progress.total ? "" : "indeterminate"}"><span style="width:${task.progress.total ? progressPercent : 35}%"></span></div>
  </div>` : "";
  return `<div class="history-card ${kind}">
    <div class="task-main-row">
      <span class="history-cover">${cover}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg></span>
      <div class="task-info">
        <b class="task-title" title="${escapeHtml(task.article.title)}">${escapeHtml(task.article.title)}</b>
        <div class="task-meta">
          <span class="state-tag ${kind}">${stateIcon} ${stateText}</span>
          <span>\xB7</span>
          <span>${formatDate(task.updatedAt)}</span>
        </div>
      </div>
    </div>
    ${progress}
    ${error}
    ${diagnostic}
    ${warning}
    <div class="task-bottom-row">
      <div class="task-stats">${stats || "<span>CSDN \u8349\u7A3F\u540C\u6B65</span>"}</div>
      ${action}
    </div>
  </div>`;
}
async function loadTasks() {
  try {
    const result = await chrome.runtime.sendMessage({ type: "GET_TASKS" });
    const all = (result?.tasks || []).sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
    currentTasksCache = all;
    const tasks = all.filter((task) => historyFilter === "all" || (historyFilter === "saved" ? task.status === "saved" : historyFilter === "failed" ? ["failed", "needs-user"].includes(task.status) : ["queued", "checking-login", "transforming", "writing", "needs-confirmation"].includes(task.status)));
    const list = $("#task-list");
    const savedCount = all.filter((t) => t.status === "saved").length;
    const failedCount = all.filter((t) => ["failed", "needs-user"].includes(t.status)).length;
    const workingCount = all.filter((t) => ["queued", "checking-login", "transforming", "writing", "needs-confirmation"].includes(t.status)).length;
    const countAll = $("#count-all");
    if (countAll) countAll.textContent = all.length ? String(all.length) : "";
    const countSaved = $("#count-saved");
    if (countSaved) countSaved.textContent = savedCount ? String(savedCount) : "";
    const countFailed = $("#count-failed");
    if (countFailed) countFailed.textContent = failedCount ? String(failedCount) : "";
    const countWorking = $("#count-working");
    if (countWorking) countWorking.textContent = workingCount ? String(workingCount) : "";
    $("#history-count").textContent = historyFilter === "all" ? "" : `${tasks.length}/${all.length} \u7BC7`;
    const badge = $("#history-badge");
    badge.textContent = all.length ? String(all.length) : "";
    const clearButton = $("#history-clear");
    clearButton.disabled = !all.length;
    $("#history-retry-all").disabled = !all.some((task) => ["failed", "needs-user"].includes(task.status));
    if (!tasks.length) {
      list.innerHTML = `<div class="empty-state-view harbor-empty-view">
        <div class="harbor-beacon-stage">
          <div class="water-ripple"></div>
          <div class="harbor-boat-card">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 17l20 0"/>
              <path d="M4 17l2 -6h12l2 6"/>
              <path d="M12 5v6"/>
              <path d="M12 5l6 3.5h-6"/>
            </svg>
            <span class="beacon-star"></span>
          </div>
        </div>
        <h2 class="empty-headline harbor-headline">${all.length ? "\u5F53\u524D\u7B5B\u9009\u4E0B\u65E0\u8BB0\u5F55" : "\u51C6\u5907\u5C31\u7EEA\uFF0C\u5F00\u542F\u6446\u6E21"}</h2>
        <p class="empty-subtext harbor-subtext">${all.length ? "\u53EF\u5C1D\u8BD5\u5207\u6362\u4E0A\u65B9\u7684\u72B6\u6001\u7B5B\u9009\u6761\u4EF6\u3002" : "\u5728\u6398\u91D1\u53D1\u6587\u65F6\u5F00\u542F\u540C\u6B65\u52FE\u9009\uFF0C\u6587\u7AE0\u4E0E\u56FE\u7247\u5C06\u5982\u671F\u6446\u6E21\u81F3\u76EE\u6807\u8349\u7A3F\u7BB1\u3002"}</p>
        ${all.length ? "" : `<button id="btn-goto-juejin" class="btn-launch-juejin btn-embark">
          <span>\u524D\u5F80\u6398\u91D1\u6587\u7AE0\u7BA1\u7406</span>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M7 17l9.2-9.2M17 17V8H8"/></svg>
        </button>
        <div class="guide-card">
          <div class="guide-card-header">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
            <span>\u53EA\u9700 3 \u6B65\u5B8C\u6210\u6446\u6E21</span>
          </div>
          <div class="guide-steps">
            <div class="guide-step-item">
              <span class="step-num-pill">1</span>
              <span class="step-title">\u6398\u91D1\u5199\u5B8C</span>
              <span class="step-desc">\u6B63\u5E38\u64B0\u5199\u5E76\u53D1\u5E03</span>
            </div>
            <div class="guide-step-item">
              <span class="step-num-pill">2</span>
              <span class="step-title">\u52FE\u9009\u540C\u6B65</span>
              <span class="step-desc">\u9762\u677F\u5F00\u542F CSDN</span>
            </div>
            <div class="guide-step-item">
              <span class="step-num-pill">3</span>
              <span class="step-title">\u8349\u7A3F\u76F4\u8FBE</span>
              <span class="step-desc">\u6253\u5F00\u8349\u7A3F\u7BB1\u786E\u8BA4</span>
            </div>
          </div>
        </div>`}
      </div>`;
      $("#btn-goto-juejin")?.addEventListener("click", () => void chrome.tabs.create({ url: "https://juejin.cn/creator/content/article/essays?status=all", active: true }));
      return;
    }
    list.innerHTML = tasks.map(taskCard).join("");
    list.querySelectorAll(".history-cover img").forEach((image) => image.addEventListener("error", () => image.remove()));
    list.querySelectorAll("[data-open]").forEach((button) => button.addEventListener("click", () => void chrome.tabs.create({ url: button.dataset.open, active: true })));
    list.querySelectorAll("[data-dryrun]").forEach((button) => button.addEventListener("click", () => void runDryRun(button.dataset.dryrun || "", button)));
    list.querySelectorAll("[data-copy-diag]").forEach((button) => button.addEventListener("click", async () => {
      const text = button.dataset.copyDiag || "";
      if (!text) return;
      try {
        await navigator.clipboard.writeText(text);
        toast("\u8BCA\u65AD\u4FE1\u606F\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F");
      } catch {
        toast("\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u590D\u5236");
      }
    }));
    list.querySelectorAll("[data-retry]").forEach((button) => button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "\u91CD\u8BD5\u4E2D\u2026";
      const retry = await chrome.runtime.sendMessage({ type: "RETRY_TASK", id: button.dataset.retry });
      if (!retry?.ok) toast(retry?.message || "\u91CD\u65B0\u540C\u6B65\u5931\u8D25");
      else toast("\u5DF2\u91CD\u65B0\u53D1\u8D77\u540C\u6B65");
      setTimeout(() => void loadTasks(), 600);
    }));
    list.querySelectorAll("[data-confirm]").forEach((button) => button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "\u66F4\u65B0\u4E2D\u2026";
      const result2 = await chrome.runtime.sendMessage({ type: "CONFIRM_TASK_UPDATE", id: button.dataset.confirm });
      if (!result2?.ok) toast(result2?.message || "\u786E\u8BA4\u66F4\u65B0\u5931\u8D25");
      else toast("\u5DF2\u786E\u8BA4\u66F4\u65B0\u8349\u7A3F");
      setTimeout(() => void loadTasks(), 500);
    }));
    list.querySelectorAll("[data-delete]").forEach((button) => button.addEventListener("click", async () => {
      if (!confirm("\u786E\u5B9A\u5220\u9664\u8FD9\u6761\u672C\u5730\u540C\u6B65\u8BB0\u5F55\u5417\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u4F1A\u5220\u9664 CSDN \u8349\u7A3F\u3002")) return;
      const result2 = await chrome.runtime.sendMessage({ type: "DELETE_TASK", id: button.dataset.delete });
      if (!result2?.ok) toast(result2?.message || "\u5220\u9664\u5931\u8D25");
      else {
        toast("\u672C\u5730\u8BB0\u5F55\u5DF2\u5220\u9664");
        await loadTasks();
      }
    }));
  } catch (error) {
    toast(error.message);
  }
}
function renderSettings(settings) {
  $("#auto-sync").checked = settings.autoSyncAfterPublish;
  $("#sync-cover").checked = settings.syncCover;
  $("#auto-summary").checked = settings.autoSummary;
  $("#append-source-link").checked = settings.appendSourceLink;
  $("#confirm-update").checked = settings.confirmDraftUpdate;
  $("#image-failure").value = settings.imageFailurePolicy;
  $("#default-category").value = settings.defaultCsdnCategory;
  $("#category-mappings").value = formatCategoryMappings(settings.categoryMappings);
}
async function saveSettingsFromForm() {
  currentSettings = normalizeSettings({
    autoSyncAfterPublish: $("#auto-sync").checked,
    syncCover: $("#sync-cover").checked,
    autoSummary: $("#auto-summary").checked,
    appendSourceLink: $("#append-source-link").checked,
    confirmDraftUpdate: $("#confirm-update").checked,
    imageFailurePolicy: $("#image-failure").value,
    defaultCsdnCategory: $("#default-category").value,
    categoryMappings: parseCategoryMappings($("#category-mappings").value)
  });
  const result = await chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings: currentSettings });
  if (!result?.ok) {
    toast(result?.message || "\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25");
    return;
  }
  renderSettings(currentSettings);
  toast("\u8BBE\u7F6E\u5DF2\u4FDD\u5B58");
}
async function loadSettings() {
  const result = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
  currentSettings = normalizeSettings(result?.settings);
  renderSettings(currentSettings);
}
async function loadCsdnCategories() {
  const hint = $("#category-hint");
  try {
    const result = await chrome.runtime.sendMessage({ type: "FETCH_CSDN_CATEGORIES" });
    if (!result?.ok || !Array.isArray(result.categories) || !result.categories.length) {
      if (result?.message) hint.textContent = `\u5206\u7C7B\u62C9\u53D6\u5931\u8D25\uFF08${result.message}\uFF09\uFF0C\u53EF\u76F4\u63A5\u624B\u52A8\u8F93\u5165\u3002`;
      return;
    }
    const datalist = $("#csdn-category-options");
    datalist.innerHTML = result.categories.slice(0, 100).map((name) => `<option value="${escapeHtml(name)}"></option>`).join("");
    hint.textContent = `\u5DF2\u8F7D\u5165\u4F60\u8D26\u53F7\u4E0B\u7684 ${result.categories.length} \u4E2A CSDN \u5206\u7C7B\u4E13\u680F\uFF0C\u70B9\u51FB\u8F93\u5165\u6846\u9009\u62E9\u3002`;
  } catch {
    hint.textContent = "\u5206\u7C7B\u62C9\u53D6\u5931\u8D25\uFF0C\u53EF\u76F4\u63A5\u624B\u52A8\u8F93\u5165\u3002";
  }
}
async function checkHealthBanner() {
  const banner = $("#health-banner");
  try {
    const result = await chrome.runtime.sendMessage({ type: "GET_HEALTH_STATUS" });
    if (!result?.alert) return;
    const status = result.status;
    const broken = status?.csdn === "broken" ? "CSDN" : "\u6398\u91D1";
    $("#health-title").textContent = `${broken}\u63A5\u53E3\u72B6\u6001\u5F02\u5E38`;
    $("#health-message").textContent = status?.message || "\u5E73\u53F0\u63A5\u53E3\u8FD1\u671F\u53D8\u52A8\uFF0C\u540C\u6B65\u53EF\u80FD\u5931\u8D25";
    banner.hidden = false;
  } catch {
  }
}
var STATUS_PAGE_URL = "https://xxcool.github.io/juejin-csdn-extension/status.html";
function closeDryRunModal() {
  $("#dryrun-modal").hidden = true;
}
function showDryRunModal(task, report) {
  const rows = [
    { label: "\u6807\u9898\u957F\u5EA6", value: `${report.titleLength} / 100 \u5B57` },
    { label: "\u6B63\u6587\u5B57\u6570", value: `\u7EA6 ${report.contentLength} \u5B57\u7B26` },
    { label: "\u547D\u4E2D\u5206\u7C7B", value: report.categories.length ? report.categories.join("\u3001") : "\u672A\u547D\u4E2D\uFF08\u5C06\u4E0D\u8BBE\u7F6E\u5206\u7C7B\uFF09" },
    { label: "\u5F85\u8F6C\u5B58\u56FE\u7247", value: report.imageCount ? `${report.imageCount} \u5F20\u5916\u94FE\u56FE\u7247` : "\u65E0\u5916\u94FE\u56FE\u7247" },
    { label: "\u5BB9\u5668\u8F6C\u6362", value: report.containerCount ? `${report.containerCount} \u4E2A ::: \u5BB9\u5668\u5C06\u8F6C\u4E3A\u5F15\u7528\u5757` : "\u65E0\u6398\u91D1\u7279\u6709\u5BB9\u5668" },
    { label: "\u4EE3\u7801\u56F4\u680F", value: `${report.codeFenceCount} \u4E2A` }
  ];
  const summary = report.summaryPreview ? `<div class="dryrun-summary"><span class="dryrun-summary-label">\u6458\u8981\u9884\u89C8</span><p>${escapeHtml(report.summaryPreview)}</p></div>` : "";
  const issues = report.issues.length ? `<div class="dryrun-issues">${report.issues.map((item) => `<p>\xB7 ${escapeHtml(item)}</p>`).join("")}</div>` : '<div class="dryrun-issues ok"><p>\xB7 \u672A\u53D1\u73B0\u963B\u65AD\u98CE\u9669\uFF0C\u53EF\u653E\u5FC3\u540C\u6B65</p></div>';
  const notices = report.notices.length ? `<div class="dryrun-notices">${report.notices.map((item) => `<p>\xB7 ${escapeHtml(item)}</p>`).join("")}</div>` : "";
  $("#dryrun-body").innerHTML = `
    <b class="dryrun-task-title" title="${escapeHtml(task.article.title)}">${escapeHtml(task.article.title)}</b>
    <div class="dryrun-grid">${rows.map((row) => `<div class="dryrun-row"><span>${row.label}</span><b>${escapeHtml(row.value)}</b></div>`).join("")}</div>
    ${summary}
    ${issues}
    ${notices}`;
  $("#dryrun-modal").hidden = false;
}
async function runDryRun(taskId, button) {
  button.disabled = true;
  const original = button.innerHTML;
  button.innerHTML = "<span>\u9884\u6F14\u4E2D\u2026</span>";
  try {
    const result = await chrome.runtime.sendMessage({ type: "DRY_RUN_TASK", id: taskId });
    if (!result?.ok) {
      toast(result?.message || "\u9884\u6F14\u5931\u8D25");
      return;
    }
    showDryRunModal(currentTasksCache.find((item) => item.id === taskId) || { article: { title: "" } }, result.report);
  } catch (error) {
    toast(error.message);
  } finally {
    button.disabled = false;
    button.innerHTML = original;
  }
}
document.querySelectorAll(".tab-button").forEach((button) => {
  button.addEventListener("click", () => switchTab(button.dataset.tab));
  button.addEventListener("keydown", (event) => {
    if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
      event.preventDefault();
      const target = button.dataset.tab === "history" ? "settings" : "history";
      const targetBtn = $(`.tab-button[data-tab="${target}"]`);
      targetBtn?.focus();
      switchTab(target);
    }
  });
});
$("#login-state").addEventListener("click", () => {
  if (loginStatus === "logged-out") void chrome.runtime.sendMessage({ type: "OPEN_CSDN_LOGIN" });
  else void checkLogin();
});
document.querySelectorAll("[data-filter]").forEach((button) => button.addEventListener("click", () => {
  historyFilter = button.dataset.filter;
  document.querySelectorAll("[data-filter]").forEach((item) => item.classList.toggle("active", item === button));
  void loadTasks();
}));
$("#history-retry-all").addEventListener("click", async () => {
  const result = await chrome.runtime.sendMessage({ type: "RETRY_FAILED_TASKS" });
  if (!result?.ok) {
    toast(result?.message || "\u6279\u91CF\u91CD\u8BD5\u5931\u8D25");
    return;
  }
  toast(result.count ? `\u5DF2\u91CD\u8BD5 ${result.count} \u4E2A\u5931\u8D25\u4EFB\u52A1` : "\u6CA1\u6709\u53EF\u91CD\u8BD5\u4EFB\u52A1");
  setTimeout(() => void loadTasks(), 500);
});
$("#history-clear").addEventListener("click", async () => {
  if (!confirm("\u786E\u5B9A\u6E05\u7A7A\u5168\u90E8\u540C\u6B65\u5386\u53F2\u5417\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u4F1A\u5220\u9664 CSDN \u8349\u7A3F\u3002")) return;
  const result = await chrome.runtime.sendMessage({ type: "CLEAR_TASKS" });
  if (!result?.ok) {
    toast(result?.message || "\u6E05\u7A7A\u5931\u8D25");
    return;
  }
  toast("\u540C\u6B65\u5386\u53F2\u5DF2\u6E05\u7A7A");
  await loadTasks();
});
["#auto-sync", "#sync-cover", "#auto-summary", "#append-source-link", "#confirm-update", "#image-failure"].forEach((selector) => $(selector).addEventListener("change", () => void saveSettingsFromForm()));
["#default-category", "#category-mappings"].forEach((selector) => $(selector).addEventListener("change", () => void saveSettingsFromForm()));
$("#health-detail").addEventListener("click", () => void chrome.tabs.create({ url: STATUS_PAGE_URL, active: true }));
$("#dryrun-close").addEventListener("click", closeDryRunModal);
$("#dryrun-modal").addEventListener("click", (event) => {
  if (event.target === $("#dryrun-modal")) closeDryRunModal();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#dryrun-modal").hidden) closeDryRunModal();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.syncTasks && $("#pane-history").classList.contains("active")) void loadTasks();
});
try {
  const version = chrome.runtime.getManifest()?.version;
  if (version) {
    const versionEl = $("#app-version");
    if (versionEl) versionEl.textContent = `\u7248\u672C v${version}`;
    const brandVersionEl = $("#brand-version");
    if (brandVersionEl) brandVersionEl.textContent = `v${version}`;
  }
} catch {
}
void loadTasks();
void loadSettings();
void loadCsdnCategories();
void checkLogin();
void checkHealthBanner();
