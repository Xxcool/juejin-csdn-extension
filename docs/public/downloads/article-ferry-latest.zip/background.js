// src/core/async.ts
async function retry(operation, attempts = 3, baseDelay = 300) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      if (attempt < attempts) await new Promise((resolve) => setTimeout(resolve, baseDelay * 2 ** (attempt - 1)));
    }
  }
  throw lastError;
}
async function mapConcurrent(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  async function consume() {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await worker(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(Math.max(1, limit), items.length) }, consume));
  return results;
}
var Semaphore = class {
  constructor(limit) {
    this.limit = limit;
  }
  active = 0;
  waiters = [];
  async run(operation) {
    while (this.active >= this.limit) await new Promise((resolve) => this.waiters.push(resolve));
    this.active++;
    try {
      return await operation();
    } finally {
      this.active--;
      this.waiters.shift()?.();
    }
  }
};

// src/core/settings.ts
var defaultSettings = {
  autoSyncAfterPublish: true,
  defaultCsdnCategory: "",
  categoryMappings: [],
  syncCover: true,
  autoSummary: true,
  appendSourceLink: true,
  imageFailurePolicy: "continue",
  confirmDraftUpdate: false
};
function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}
function normalizeSettings(value) {
  const input = value && typeof value === "object" ? value : {};
  const mappings = Array.isArray(input.categoryMappings) ? input.categoryMappings.map((item) => ({ sourceTag: clean(item?.sourceTag), targetCategory: clean(item?.targetCategory) })).filter((item) => item.sourceTag && item.targetCategory) : [];
  return {
    autoSyncAfterPublish: input.autoSyncAfterPublish !== false,
    defaultCsdnCategory: clean(input.defaultCsdnCategory),
    categoryMappings: mappings,
    syncCover: input.syncCover !== false,
    autoSummary: input.autoSummary !== false,
    appendSourceLink: input.appendSourceLink !== false,
    imageFailurePolicy: input.imageFailurePolicy === "abort" ? "abort" : "continue",
    confirmDraftUpdate: input.confirmDraftUpdate === true
  };
}
function resolveCsdnCategories(tags, settings) {
  const normalizedTags = new Set(tags.map((tag) => tag.trim().toLocaleLowerCase()).filter(Boolean));
  const categories = settings.categoryMappings.filter((mapping) => normalizedTags.has(mapping.sourceTag.trim().toLocaleLowerCase())).map((mapping) => mapping.targetCategory.trim()).filter(Boolean);
  if (!categories.length && settings.defaultCsdnCategory.trim()) categories.push(settings.defaultCsdnCategory.trim());
  return [...new Set(categories)];
}
function shouldConfirmDraftUpdate(settings, articleId) {
  return settings.confirmDraftUpdate && !!articleId;
}

// src/core/task.ts
function articleIdentityKeys(article) {
  return [...new Set([article.id, article.sourceDraftId].filter((value) => !!value))];
}
function findMatchingTask(tasks, article) {
  const identities = new Set(articleIdentityKeys(article));
  return tasks.find((task) => articleIdentityKeys(task.article).some((identity) => identities.has(identity)) && task.platform === "csdn");
}
function extractCsdnArticleId(draftUrl) {
  if (!draftUrl) return void 0;
  try {
    return new URL(draftUrl).searchParams.get("articleId") || void 0;
  } catch {
    return void 0;
  }
}
function isInterruptedTask(task) {
  return ["queued", "checking-login", "transforming"].includes(task.status) || task.status === "writing" && !!task.csdnArticleId;
}
function isUncertainCreateTask(task) {
  return task.status === "writing" && !task.csdnArticleId;
}
function isActiveTask(task) {
  return ["queued", "checking-login", "transforming", "writing"].includes(task.status);
}
function isRetryableTask(task) {
  return ["failed", "needs-user"].includes(task.status);
}
function canDeleteTask(task) {
  return !isActiveTask(task);
}

// src/core/store.ts
var KEY = "syncTasks";
var SETTINGS_KEY = "settings";
var MAPPING_PREFIX = "csdnDraftMapping:";
var storageMutex = new Semaphore(1);
function toStorageTask(task) {
  return task.article?.markdown ? { ...task, article: { ...task.article, markdown: "" } } : task;
}
async function migrateStoredTasks() {
  const raw = (await chrome.storage.local.get(KEY))[KEY] || [];
  if (!raw.some((task) => task.article?.markdown)) return false;
  await saveTasks(raw);
  return true;
}
function uniqueTasks(tasks) {
  const identities = /* @__PURE__ */ new Set();
  return [...tasks].sort((a, b2) => Date.parse(b2.updatedAt) - Date.parse(a.updatedAt)).filter((task) => {
    const identity = `${task.platform}:${task.article.id}`;
    if (identities.has(identity)) return false;
    identities.add(identity);
    return true;
  });
}
async function allTasks() {
  return uniqueTasks((await chrome.storage.local.get(KEY))[KEY] || []);
}
async function saveTasks(tasks) {
  await chrome.storage.local.set({ [KEY]: tasks.slice(0, 200).map(toStorageTask) });
}
async function saveDraftMapping(articleId, csdnArticleId, draftUrl) {
  await chrome.storage.local.set({ [MAPPING_PREFIX + articleId]: { articleId, csdnArticleId, draftUrl, updatedAt: (/* @__PURE__ */ new Date()).toISOString() } });
}
async function getDraftMapping(articleId) {
  return (await chrome.storage.local.get(MAPPING_PREFIX + articleId))[MAPPING_PREFIX + articleId];
}
async function saveArticleDraftMapping(article, csdnArticleId, draftUrl) {
  for (const identity of articleIdentityKeys(article)) await saveDraftMapping(identity, csdnArticleId, draftUrl);
}
async function getArticleDraftMapping(article) {
  for (const identity of articleIdentityKeys(article)) {
    const mapping = await getDraftMapping(identity);
    if (mapping) return mapping;
  }
  return void 0;
}
async function preserveTaskMappings(tasks) {
  for (const task of tasks) if (task.csdnArticleId) await saveArticleDraftMapping(task.article, task.csdnArticleId, task.draftUrl);
}
async function deleteTask(id) {
  await storageMutex.run(async () => {
    const tasks = await allTasks();
    const task = tasks.find((item) => item.id === id);
    if (task?.csdnArticleId) await saveArticleDraftMapping(task.article, task.csdnArticleId, task.draftUrl);
    await saveTasks(tasks.filter((item) => item.id !== id));
  });
}
async function putTask(task) {
  await storageMutex.run(async () => {
    const tasks = await allTasks();
    const i = tasks.findIndex((x2) => x2.id === task.id);
    if (i >= 0) tasks[i] = task;
    else tasks.unshift(task);
    await saveTasks(tasks);
  });
}
async function patchTask(id, patch) {
  return storageMutex.run(async () => {
    const tasks = await allTasks();
    const task = tasks.find((x2) => x2.id === id);
    if (!task) return;
    Object.assign(task, patch, { updatedAt: (/* @__PURE__ */ new Date()).toISOString() });
    await saveTasks(tasks);
    return task;
  });
}
async function clearAllTasks() {
  await storageMutex.run(async () => {
    const tasks = await allTasks();
    await preserveTaskMappings(tasks);
    await saveTasks([]);
  });
}
async function getSettings() {
  return normalizeSettings({ ...defaultSettings, ...(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY] || {} });
}
async function saveSettings(settings) {
  await chrome.storage.local.set({ [SETTINGS_KEY]: normalizeSettings(settings) });
}

// src/core/diagnostic.ts
var suggestions = {
  login: "\u8BF7\u767B\u5F55 CSDN \u540E\u91CD\u65B0\u540C\u6B65\u3002",
  network: "\u8BF7\u68C0\u67E5\u7F51\u7EDC\u8FDE\u63A5\uFF0C\u7A0D\u540E\u91CD\u65B0\u540C\u6B65\u3002",
  "rate-limit": "\u5E73\u53F0\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
  "platform-change": "\u5E73\u53F0\u63A5\u53E3\u6216\u9875\u9762\u53EF\u80FD\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u5347\u7EA7\u63D2\u4EF6\u6216\u53CD\u9988\u6B64\u95EE\u9898\u3002",
  content: "\u8BF7\u68C0\u67E5\u6587\u7AE0\u6807\u9898\u3001\u6B63\u6587\u548C\u56FE\u7247\u540E\u91CD\u65B0\u540C\u6B65\u3002",
  blocked: "\u8BE5 CSDN \u6587\u7AE0\u5DF2\u516C\u5F00\u53D1\u5E03\uFF0C\u4E3A\u4FDD\u62A4\u7EBF\u4E0A\u5185\u5BB9\u5DF2\u963B\u65AD\u8986\u76D6\u3002\u5982\u9700\u91CD\u65B0\u540C\u6B65\uFF0C\u8BF7\u5220\u9664\u5BF9\u5E94\u8BB0\u5F55\u540E\u53E6\u5B58\u4E3A\u65B0\u8349\u7A3F\u3002",
  interrupted: "\u8BF7\u5148\u68C0\u67E5 CSDN \u8349\u7A3F\u7BB1\uFF0C\u518D\u51B3\u5B9A\u662F\u5426\u91CD\u8BD5\u3002",
  unknown: "\u8BF7\u7A0D\u540E\u91CD\u8BD5\uFF1B\u82E5\u6301\u7EED\u5931\u8D25\uFF0C\u8BF7\u590D\u5236\u6B64\u8BCA\u65AD\u4FE1\u606F\u8FDB\u884C\u53CD\u9988\u3002"
};
var SyncError = class extends Error {
  category;
  stage;
  constructor(message, category = "unknown", stage = "validation") {
    super(message);
    this.name = "SyncError";
    this.category = category;
    this.stage = stage;
  }
};
function cleanMessage(message) {
  return message.replace(/([?&](?:token|sign|signature|key|authorization)=)[^&\s]+/gi, "$1***").replace(/(authorization|cookie|token|signature)\s*[:=]\s*[^\s,;]+/gi, "$1=***").slice(0, 500);
}
function classifyMessage(message) {
  let category = "unknown";
  if (/登录|未登录|401|unauthor/i.test(message)) category = "login";
  else if (/429|限流|频繁|too many/i.test(message)) category = "rate-limit";
  else if (/标题|正文不完整|非图片内容|图片地址|图片.*失败/i.test(message)) category = "content";
  else if (/签名|鉴权异常|invalid signature|返回错误码|没有返回草稿标识|接口.*(?:变化|异常)|\((?:400|403|404)\)/i.test(message)) category = "platform-change";
  else if (/timeout|超时|failed to fetch|network|网络|连接/i.test(message)) category = "network";
  else if (/中断|无法确认是否已保存/i.test(message)) category = "interrupted";
  return category;
}
function classifySyncError(error, stage) {
  const raw = error instanceof Error ? error.message : String(error || "\u672A\u77E5\u9519\u8BEF");
  const message = cleanMessage(raw || "\u672A\u77E5\u9519\u8BEF");
  const syncError = error instanceof SyncError ? error : void 0;
  const category = syncError?.category ?? classifyMessage(message);
  return { stage: syncError?.stage ?? stage, category, message, suggestion: suggestions[category], occurredAt: (/* @__PURE__ */ new Date()).toISOString() };
}

// src/core/message.ts
var messageTypes = [
  "SYNC_NEW_ARTICLE",
  "CHECK_CSDN_STATUS",
  "OPEN_CSDN_LOGIN",
  "REPORT_JUEJIN_UUID",
  "SYNC_HISTORY_ARTICLE",
  "RESUME_PENDING_HISTORY",
  "GET_TASKS",
  "GET_SETTINGS",
  "SAVE_SETTINGS",
  "RETRY_TASK",
  "CONFIRM_TASK_UPDATE",
  "RETRY_FAILED_TASKS",
  "DELETE_TASK",
  "CLEAR_TASKS",
  "FETCH_CSDN_CATEGORIES",
  "DRY_RUN_TASK",
  "GET_HEALTH_STATUS"
];
function isSupportedMessage(value) {
  return !!value && typeof value === "object" && messageTypes.includes(value.type);
}

// src/core/notify.ts
var NOTIFY_DURATION_MS = 1e4;
var NOTIFY_IMAGE_COUNT = 3;
function buildTaskNotification(task, durationMs) {
  const needsUser = task.status === "failed" || task.status === "needs-user";
  const longRunning = durationMs >= NOTIFY_DURATION_MS || (task.stats?.imageTotal ?? 0) >= NOTIFY_IMAGE_COUNT;
  if (!longRunning && !needsUser) return void 0;
  const title = task.article.title;
  if (task.status === "saved") {
    const imageStats = task.stats?.imageTotal ? `\uFF0C\u8F6C\u5B58\u56FE\u7247 ${task.stats.imageSucceeded}/${task.stats.imageTotal}` : "";
    return { id: task.id, kind: "saved", title: "\u6587\u7AE0\u5DF2\u62B5\u8FBE CSDN \u8349\u7A3F\u7BB1", message: `\u300C${title}\u300D\u4FDD\u5B58\u6210\u529F${imageStats}`, draftUrl: task.draftUrl };
  }
  if (task.status === "failed" || task.status === "needs-user") {
    return { id: task.id, kind: "failed", title: "\u6587\u7AE0\u6446\u6E21\u540C\u6B65\u9700\u8981\u5904\u7406", message: `\u300C${title}\u300D${task.diagnostic?.message || task.error || "\u540C\u6B65\u5931\u8D25\uFF0C\u70B9\u51FB\u67E5\u770B\u8BE6\u60C5"}` };
  }
  return void 0;
}
async function showTaskNotification(notification) {
  try {
    await chrome.notifications.create(notification.id, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("logo-128.png"),
      title: notification.title,
      message: notification.message,
      priority: 2
    });
  } catch {
  }
}

// src/core/health.ts
var HEALTH_CHECK_ALARM = "health-check";
var HEALTH_URL = "https://raw.githubusercontent.com/Xxcool/juejin-csdn-extension/main/health.json";
var STATUS_PAGE_URL = "https://xxcool.github.io/juejin-csdn-extension/status.html";
function parseHealthPayload(value) {
  const input = value && typeof value === "object" ? value : {};
  const level = (raw) => raw === "ok" || raw === "degraded" || raw === "broken" ? raw : "unknown";
  return {
    csdn: level(input.csdn),
    juejin: level(input.juejin),
    message: typeof input.message === "string" ? input.message.slice(0, 200) : "",
    sourceUrl: STATUS_PAGE_URL,
    updatedAt: typeof input.updatedAt === "string" ? input.updatedAt : "",
    checkedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function fetchHealthStatus() {
  try {
    const response = await fetch(HEALTH_URL, { signal: AbortSignal.timeout(8e3) });
    if (!response.ok) return void 0;
    return parseHealthPayload(await response.json());
  } catch {
    return void 0;
  }
}
async function runHealthCheck() {
  const status = await fetchHealthStatus();
  if (status) {
    try {
      await chrome.storage.local.set({ healthStatus: status });
    } catch {
    }
  }
  return status;
}
async function getCachedHealth() {
  try {
    return (await chrome.storage.local.get("healthStatus")).healthStatus || void 0;
  } catch {
    return void 0;
  }
}
var HEALTH_REFRESH_MS = 12 * 60 * 60 * 1e3;
async function refreshHealthIfNeeded(force = false) {
  if (!force) {
    const cached = await getCachedHealth();
    if (cached?.checkedAt && Date.now() - Date.parse(cached.checkedAt) < HEALTH_REFRESH_MS) return cached;
  }
  return runHealthCheck();
}
function isHealthAlert(status) {
  return status?.csdn === "broken" || status?.juejin === "broken";
}

// src/source/juejin-api.ts
var API_BASE = "https://api.juejin.cn/content_api/v1";
async function post(path, body, uuid) {
  if (!uuid) throw new SyncError("\u65E0\u6CD5\u8BFB\u53D6\u6398\u91D1\u8BF7\u6C42\u6807\u8BC6\uFF0C\u8BF7\u5237\u65B0\u6587\u7AE0\u5217\u8868\u540E\u91CD\u8BD5", "platform-change", "content");
  const query = new URLSearchParams({ aid: "2608", uuid, spider: "0" });
  const response = await fetch(`${API_BASE}${path}?${query}`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const status = response.status;
    throw new SyncError(`\u6398\u91D1 API \u8BF7\u6C42\u5931\u8D25 (${status})`, status === 429 ? "rate-limit" : status >= 500 ? "network" : "platform-change", "content");
  }
  const result = await response.json();
  if (result.err_no !== 0) throw new SyncError(result.err_msg || "\u6398\u91D1\u8FD4\u56DE\u9519\u8BEF", "platform-change", "content");
  return result.data;
}
async function fetchDraftContent(draftId, uuid) {
  const detail = await post("/article_draft/detail", { draft_id: draftId }, uuid);
  const draft = detail.article_draft;
  const markdown = draft?.mark_content?.trim() || "";
  if (markdown.length < 20) throw new SyncError("\u6398\u91D1\u8349\u7A3F\u6B63\u6587\u4E3A\u7A7A\u6216\u8FC7\u77ED", "content", "content");
  const summary = draft?.brief?.trim() || void 0;
  return { title: draft?.title?.trim() || "", markdown, summary, tags: (draft?.tags || []).map((tag) => tag.tag_name || "").filter(Boolean), cover: draft?.cover_image || void 0 };
}
async function fetchJuejinDraftByDraftId(draftId, uuid, titleFallback = "") {
  const content = await fetchDraftContent(draftId, uuid);
  return {
    id: draftId,
    sourceDraftId: draftId,
    title: content.title || titleFallback,
    markdown: content.markdown,
    summary: content.summary,
    tags: content.tags,
    cover: content.cover,
    sourceUrl: `https://juejin.cn/editor/drafts/${draftId}`
  };
}
async function fetchJuejinDraftByArticleId(articleId, uuid, titleFallback = "") {
  const pageSize = 100;
  let entry;
  for (let pageNo = 1; !entry; pageNo++) {
    const articles = await post("/article/list_by_user", {
      page_no: pageNo,
      page_size: pageSize,
      audit_status: null,
      status: null
    }, uuid);
    entry = articles.find((item) => String(item.article_info?.article_id || "") === articleId);
    if (entry || articles.length < pageSize) break;
  }
  const draftId = entry?.article_info?.draft_id;
  if (!draftId) throw new SyncError("\u672A\u5728\u6398\u91D1\u521B\u4F5C\u8005\u6587\u7AE0\u4E2D\u627E\u5230\u5BF9\u5E94\u8349\u7A3F", "platform-change", "content");
  const content = await fetchDraftContent(String(draftId), uuid);
  return {
    id: articleId,
    sourceDraftId: String(draftId),
    title: content.title || entry?.article_info?.title?.trim() || titleFallback,
    markdown: content.markdown,
    summary: content.summary,
    tags: content.tags.length ? content.tags : (entry?.tags || []).map((tag) => tag.tag_name || "").filter(Boolean),
    cover: content.cover || entry?.article_info?.cover_image || void 0,
    sourceUrl: `https://juejin.cn/post/${articleId}`
  };
}

// src/targets/csdn.ts
var csdnAdapter = { id: "csdn", name: "CSDN", editorUrl: "https://editor.csdn.net/md/", transform(article) {
  return { ...article };
} };

// node_modules/marked/lib/marked.esm.js
function A() {
  return { async: false, breaks: false, extensions: null, gfm: true, hooks: null, pedantic: false, renderer: null, silent: false, tokenizer: null, walkTokens: null };
}
var R = A();
function j(l3) {
  R = l3;
}
var z = { exec: () => null };
function I(l3) {
  let e = [];
  return (t) => {
    let n = Math.max(0, Math.min(3, t - 1)), s = e[n];
    return s || (s = l3(n), e[n] = s), s;
  };
}
function k(l3, e = "") {
  let t = typeof l3 == "string" ? l3 : l3.source, n = { replace: (s, r) => {
    let i = typeof r == "string" ? r : r.source;
    return i = i.replace(m.caret, "$1"), t = t.replace(s, i), n;
  }, getRegex: () => new RegExp(t, e) };
  return n;
}
var Oe = ((l3 = "") => {
  try {
    return !!new RegExp("(?<=1)(?<!1)" + l3);
  } catch {
    return false;
  }
})();
var m = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] +\S/, listReplaceTask: /^\[[ xX]\] +/, listTaskCheckbox: /\[[ xX]\]/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (l3) => new RegExp(`^( {0,3}${l3})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: I((l3) => new RegExp(`^ {0,${l3}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)), hrRegex: I((l3) => new RegExp(`^ {0,${l3}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`)), fencesBeginRegex: I((l3) => new RegExp(`^ {0,${l3}}(?:\`\`\`|~~~)`)), headingBeginRegex: I((l3) => new RegExp(`^ {0,${l3}}#`)), htmlBeginRegex: I((l3) => new RegExp(`^ {0,${l3}}<(?:[a-z].*>|!--)`, "i")), blockquoteBeginRegex: I((l3) => new RegExp(`^ {0,${l3}}>`)) };
var Te = /^(?:[ \t]*(?:\n|$))+/;
var we = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/;
var ye = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
var q = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
var Pe = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
var U = / {0,3}(?:[*+-]|\d{1,9}[.)])/;
var oe = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/;
var ae = k(oe).replace(/bull/g, U).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex();
var Se = k(oe).replace(/bull/g, U).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex();
var K = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/;
var _e = /^[^\n]+/;
var W = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/;
var $e = k(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", W).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
var Le = k(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g, U).getRegex();
var Q = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
var X = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
var Ee = k("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", X).replace("tag", Q).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
var le = (l3) => k(K).replace("hr", q).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", l3).replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Q).getRegex();
var ze = le(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/);
var Me = le(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/);
var Ae = k(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Me).getRegex();
var J = { blockquote: Ae, code: we, def: $e, fences: ye, heading: Pe, hr: q, html: Ee, lheading: ae, list: Le, newline: Te, paragraph: ze, table: z, text: _e };
var se = k("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", q).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Q).getRegex();
var Ie = { ...J, lheading: Se, table: se, paragraph: k(K).replace("hr", q).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", se).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Q).getRegex() };
var Ce = { ...J, html: k(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", X).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: z, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: k(K).replace("hr", q).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ae).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() };
var Be = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
var De = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
var ue = /^( {2,}|\\)\n(?!\s*$)/;
var qe = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
var _ = /[\p{P}\p{S}]/u;
var C = /[\s\p{P}\p{S}]/u;
var v = /[^\s\p{P}\p{S}]/u;
var ve = k(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, C).getRegex();
var He = /[\p{Pi}\p{Ps}"']/u;
var pe = /(?!~)[\p{P}\p{S}]/u;
var Ze = /(?!~)[\s\p{P}\p{S}]/u;
var Ge = /(?:[^\s\p{P}\p{S}]|~)/u;
var Qe = k(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", Oe ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex();
var ce = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/;
var Ne = k(ce, "u").replace(/punct/g, _).getRegex();
var je = k(ce, "u").replace(/punct/g, pe).getRegex();
var Fe = /^(?:\*+(?:((?!\*)(?!openQuote)punct)|([^\s*]))?)|^_+(?:((?!_)(?!openQuote)punct)|([^\s_]))?/;
var Ue = k(Fe, "u").replace(/openQuote/g, He).replace(/punct/g, _).getRegex();
var he = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)";
var Ke = k(he, "gu").replace(/notPunctSpace/g, v).replace(/punctSpace/g, C).replace(/punct/g, _).getRegex();
var We = k(he, "gu").replace(/notPunctSpace/g, Ge).replace(/punctSpace/g, Ze).replace(/punct/g, pe).getRegex();
var Xe = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)[\\s](\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|(?:(?!\\*)punct|notPunctSpace)(\\*+)(?!\\*)(?=notPunctSpace)";
var Je = k(Xe, "gu").replace(/notPunctSpace/g, v).replace(/punctSpace/g, C).replace(/punct/g, _).getRegex();
var Ve = k("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, v).replace(/punctSpace/g, C).replace(/punct/g, _).getRegex();
var Ye = "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)[\\s](_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)|(?:(?!_)punct|notPunctSpace)(_+)(?!_)(?=notPunctSpace)";
var et = k(Ye, "gu").replace(/notPunctSpace/g, v).replace(/punctSpace/g, C).replace(/punct/g, _).getRegex();
var tt = k(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, _).getRegex();
var nt = "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)";
var rt = k(nt, "gu").replace(/notPunctSpace/g, v).replace(/punctSpace/g, C).replace(/punct/g, _).getRegex();
var st = k(/\\(punct)/, "gu").replace(/punct/g, _).getRegex();
var it = k(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
var ot = k(X).replace("(?:-->|$)", "-->").getRegex();
var at = k("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", ot).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
var G = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/;
var lt = k(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", G).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]+|(?=\))/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
var ke = k(/^!?\[(label)\]\[(ref)\]/).replace("label", G).replace("ref", W).getRegex();
var de = k(/^!?\[(ref)\](?:\[\])?/).replace("ref", W).getRegex();
var ut = k("reflink|nolink(?!\\()", "g").replace("reflink", ke).replace("nolink", de).getRegex();
var ie = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/;
var V = { _backpedal: z, anyPunctuation: st, autolink: it, blockSkip: Qe, br: ue, code: De, del: z, delLDelim: z, delRDelim: z, emStrongLDelim: Ne, emStrongRDelimAst: Ke, emStrongRDelimUnd: Ve, escape: Be, link: lt, nolink: de, punctuation: ve, reflink: ke, reflinkSearch: ut, tag: at, text: qe, url: z };
var pt = { ...V, emStrongLDelim: Ue, emStrongRDelimAst: Je, emStrongRDelimUnd: et, link: k(/^!?\[(label)\]\((.*?)\)/).replace("label", G).getRegex(), reflink: k(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", G).getRegex() };
var F = { ...V, emStrongRDelimAst: We, emStrongLDelim: je, delLDelim: tt, delRDelim: rt, url: k(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", ie).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: k(/^(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", ie).getRegex() };
var ct = { ...F, br: k(ue).replace("{2,}", "*").getRegex(), text: k(F.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() };
var H = { normal: J, gfm: Ie, pedantic: Ce };
var B = { normal: V, gfm: F, breaks: ct, pedantic: pt };
var ht = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
var ge = (l3) => ht[l3];
function T(l3, e) {
  if (e) {
    if (m.escapeTest.test(l3)) return l3.replace(m.escapeReplace, ge);
  } else if (m.escapeTestNoEncode.test(l3)) return l3.replace(m.escapeReplaceNoEncode, ge);
  return l3;
}
function Y(l3) {
  try {
    l3 = encodeURI(l3).replace(m.percentDecode, "%");
  } catch {
    return null;
  }
  return l3;
}
function ee(l3, e) {
  let t = l3.replace(m.findPipe, (r, i, o) => {
    let u = false, a = i;
    for (; --a >= 0 && o[a] === "\\"; ) u = !u;
    return u ? "|" : " |";
  }), n = t.split(m.splitPipe), s = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n.at(-1)?.trim() && n.pop(), e) if (n.length > e) n.splice(e);
  else for (; n.length < e; ) n.push("");
  for (; s < n.length; s++) n[s] = n[s].trim().replace(m.slashPipe, "|");
  return n;
}
function $(l3, e, t) {
  let n = l3.length;
  if (n === 0) return "";
  let s = 0;
  for (; s < n; ) {
    let r = l3.charAt(n - s - 1);
    if (r === e && !t) s++;
    else if (r !== e && t) s++;
    else break;
  }
  return l3.slice(0, n - s);
}
function te(l3) {
  let e = l3.split(`
`), t = e.length - 1;
  for (; t >= 0 && m.blankLine.test(e[t]); ) t--;
  return e.length - t <= 2 ? l3 : e.slice(0, t + 1).join(`
`);
}
function fe(l3, e) {
  if (l3.indexOf(e[1]) === -1) return -1;
  let t = 0;
  for (let n = 0; n < l3.length; n++) if (l3[n] === "\\") n++;
  else if (l3[n] === e[0]) t++;
  else if (l3[n] === e[1] && (t--, t < 0)) return n;
  return t > 0 ? -2 : -1;
}
function me(l3, e = 0) {
  let t = e, n = "";
  for (let s of l3) if (s === "	") {
    let r = 4 - t % 4;
    n += " ".repeat(r), t += r;
  } else n += s, t++;
  return n;
}
function xe(l3, e, t, n, s) {
  let r = e.href, i = e.title || null, o = l3[1].replace(s.other.outputLinkReplace, "$1"), u = l3[0].charAt(0) === "!";
  n.state.inLink = true;
  let a = n.state.linkEmitted, p = n.state.inRawBlock;
  n.state.linkEmitted = false;
  let c = n.inlineTokens(o), h = n.state.linkEmitted;
  if (n.state.linkEmitted = a, n.state.inLink = false, !u) {
    if (h) {
      n.state.inRawBlock = p;
      return;
    }
    n.state.linkEmitted = true;
  }
  return { type: u ? "image" : "link", raw: t, href: r, title: i, text: o, tokens: c };
}
function kt(l3, e, t) {
  let n = l3.match(t.other.indentCodeCompensation);
  if (n === null) return e;
  let s = n[1];
  return e.split(`
`).map((r) => {
    let i = r.match(t.other.beginningSpace);
    if (i === null) return r;
    let [o] = i;
    return o.length >= s.length ? r.slice(s.length) : r;
  }).join(`
`);
}
var y = class {
  options;
  rules;
  lexer;
  constructor(e) {
    this.options = e || R;
  }
  space(e) {
    let t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0) return { type: "space", raw: t[0] };
  }
  code(e) {
    let t = this.rules.block.code.exec(e);
    if (t) {
      let n = this.options.pedantic ? t[0] : te(t[0]), s = n.replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: n, codeBlockStyle: "indented", text: s };
    }
  }
  fences(e) {
    let t = this.rules.block.fences.exec(e);
    if (t) {
      let n = t[0], s = kt(n, t[3] || "", this.rules);
      return { type: "code", raw: n, lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2], text: s };
    }
  }
  heading(e) {
    let t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (this.rules.other.endingHash.test(n)) {
        let s = $(n, "#");
        (this.options.pedantic || !s || this.rules.other.endingSpaceChar.test(s)) && (n = s.trim());
      }
      return { type: "heading", raw: $(t[0], `
`), depth: t[1].length, text: n, tokens: this.lexer.inline(n) };
    }
  }
  hr(e) {
    let t = this.rules.block.hr.exec(e);
    if (t) return { type: "hr", raw: $(t[0], `
`) };
  }
  blockquote(e) {
    let t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = $(t[0], `
`).split(`
`), s = "", r = "", i = [];
      for (; n.length > 0; ) {
        let o = false, u = [], a;
        for (a = 0; a < n.length; a++) if (this.rules.other.blockquoteStart.test(n[a])) u.push(n[a]), o = true;
        else if (!o) u.push(n[a]);
        else break;
        n = n.slice(a);
        let p = u.join(`
`), c = p.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        s = s ? `${s}
${p}` : p, r = r ? `${r}
${c}` : c;
        let h = this.lexer.state.top;
        if (this.lexer.state.top = true, this.lexer.blockTokens(c, i, true), this.lexer.state.top = h, n.length === 0) break;
        let d = i.at(-1);
        if (d?.type === "code") break;
        if (d?.type === "blockquote") {
          let O = d, g = n.join(`
`), w = O.raw + `
` + g.replace(this.rules.other.blockquoteSetextReplace2, ""), E = this.blockquote(w);
          i[i.length - 1] = E, s = `${s}
${g}`, r = r.substring(0, r.length - O.text.length) + E.text;
          break;
        } else if (d?.type === "list") {
          let O = d, g = O.raw + `
` + n.join(`
`), w = this.list(g);
          i[i.length - 1] = w, s = s.substring(0, s.length - d.raw.length) + w.raw, r = r.substring(0, r.length - O.raw.length) + w.raw, n = g.substring(i.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: s, tokens: i, text: r };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim(), s = n.length > 1, r = { type: "list", raw: "", ordered: s, start: s ? +n.slice(0, -1) : "", loose: false, items: [] };
      n = s ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = s ? n : "[*+-]");
      let i = this.rules.other.listItemRegex(n), o = false;
      for (; e; ) {
        let a = false, p = "", c = "";
        if (!(t = i.exec(e)) || this.rules.block.hr.test(e)) break;
        p = t[0], e = e.substring(p.length);
        let h = me(t[2].split(`
`, 1)[0], t[1].length), d = e.split(`
`, 1)[0], O = !h.trim(), g = 0;
        if (this.options.pedantic ? (g = 2, c = h.trimStart()) : O ? g = t[1].length + 1 : (g = h.search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, c = h.slice(g), g += t[1].length), O && this.rules.other.blankLine.test(d) && (p += d + `
`, e = e.substring(d.length + 1), a = true), !a) {
          let w = this.rules.other.nextBulletRegex(g), E = this.rules.other.hrRegex(g), ne = this.rules.other.fencesBeginRegex(g), re = this.rules.other.headingBeginRegex(g), be = this.rules.other.htmlBeginRegex(g), Re = this.rules.other.blockquoteBeginRegex(g);
          for (; e; ) {
            let N = e.split(`
`, 1)[0], D;
            if (d = N, this.options.pedantic ? (d = d.replace(this.rules.other.listReplaceNesting, "  "), D = d) : D = d.replace(this.rules.other.tabCharGlobal, "    "), ne.test(d) || re.test(d) || be.test(d) || Re.test(d) || w.test(d) || E.test(d)) break;
            if (D.search(this.rules.other.nonSpaceChar) >= g || !d.trim()) c += `
` + D.slice(g);
            else {
              if (O || h.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || ne.test(h) || re.test(h) || E.test(h)) break;
              c += `
` + d;
            }
            O = !d.trim(), p += N + `
`, e = e.substring(N.length + 1), h = D.slice(g);
          }
        }
        r.loose || (o ? r.loose = true : this.rules.other.doubleBlankLine.test(p) && (o = true)), r.items.push({ type: "list_item", raw: p, task: !!this.options.gfm && this.rules.other.listIsTask.test(c), loose: false, text: c, tokens: [] }), r.raw += p;
      }
      let u = r.items.at(-1);
      if (u) u.raw = u.raw.trimEnd(), u.text = u.text.trimEnd();
      else return;
      r.raw = r.raw.trimEnd();
      for (let a of r.items) if (this.lexer.state.top = false, a.tokens = this.lexer.blockTokens(a.text, []), !r.loose) {
        let p = a.tokens.filter((h) => h.type === "space"), c = p.length > 0 && p.some((h) => this.rules.other.anyLine.test(h.raw));
        r.loose = c;
      }
      for (let a of r.items) {
        let p = a.tokens[0];
        if (a.task && (p?.type === "text" || p?.type === "paragraph")) {
          a.text = a.text.replace(this.rules.other.listReplaceTask, ""), p.raw = p.raw.replace(this.rules.other.listReplaceTask, ""), p.text = p.text.replace(this.rules.other.listReplaceTask, "");
          for (let h = this.lexer.inlineQueue.length - 1; h >= 0; h--) if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[h].src)) {
            this.lexer.inlineQueue[h].src = this.lexer.inlineQueue[h].src.replace(this.rules.other.listReplaceTask, "");
            break;
          }
          let c = this.rules.other.listTaskCheckbox.exec(a.raw);
          if (c) {
            let h = { type: "checkbox", raw: c[0] + " ", checked: c[0] !== "[ ]" };
            a.checked = h.checked, r.loose ? a.tokens[0] && ["paragraph", "text"].includes(a.tokens[0].type) && "tokens" in a.tokens[0] && a.tokens[0].tokens ? (a.tokens[0].raw = h.raw + a.tokens[0].raw, a.tokens[0].text = h.raw + a.tokens[0].text, a.tokens[0].tokens.unshift(h)) : a.tokens.unshift({ type: "paragraph", raw: h.raw, text: h.raw, tokens: [h] }) : a.tokens.unshift(h);
          }
        } else a.task && (a.task = false);
      }
      if (r.loose) for (let a of r.items) {
        a.loose = true;
        for (let p of a.tokens) p.type === "text" && (p.type = "paragraph");
      }
      return r;
    }
  }
  html(e) {
    let t = this.rules.block.html.exec(e);
    if (t) {
      let n = te(t[0]);
      return { type: "html", block: true, raw: n, pre: t[1] === "pre" || t[1] === "script" || t[1] === "style", text: n };
    }
  }
  def(e) {
    let t = this.rules.block.def.exec(e);
    if (t) {
      let n = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), s = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return { type: "def", tag: n, raw: $(t[0], `
`), href: s, title: r };
    }
  }
  table(e) {
    let t = this.rules.block.table.exec(e);
    if (!t || !this.rules.other.tableDelimiter.test(t[2])) return;
    let n = ee(t[1]), s = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), r = t[3]?.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], i = { type: "table", raw: $(t[0], `
`), header: [], align: [], rows: [] };
    if (n.length === s.length) {
      for (let o of s) this.rules.other.tableAlignRight.test(o) ? i.align.push("right") : this.rules.other.tableAlignCenter.test(o) ? i.align.push("center") : this.rules.other.tableAlignLeft.test(o) ? i.align.push("left") : i.align.push(null);
      for (let o = 0; o < n.length; o++) i.header.push({ text: n[o], tokens: this.lexer.inline(n[o]), header: true, align: i.align[o] });
      for (let o of r) i.rows.push(ee(o, i.header.length).map((u, a) => ({ text: u, tokens: this.lexer.inline(u), header: false, align: i.align[a] })));
      return i;
    }
  }
  lheading(e) {
    let t = this.rules.block.lheading.exec(e);
    if (t) {
      let n = t[1].trim();
      return { type: "heading", raw: $(t[0], `
`), depth: t[2].charAt(0) === "=" ? 1 : 2, text: n, tokens: this.lexer.inline(n) };
    }
  }
  paragraph(e) {
    let t = this.rules.block.paragraph.exec(e);
    if (t) {
      let n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return { type: "paragraph", raw: t[0], text: n, tokens: this.lexer.inline(n) };
    }
  }
  text(e) {
    let t = this.rules.block.text.exec(e);
    if (t) return { type: "text", raw: t[0], text: t[0], tokens: this.lexer.inline(t[0]) };
  }
  escape(e) {
    let t = this.rules.inline.escape.exec(e);
    if (t) return { type: "escape", raw: t[0], text: t[1] };
  }
  tag(e) {
    let t = this.rules.inline.tag.exec(e);
    if (t) return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = true : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = false), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = true : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = false), { type: "html", raw: t[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: false, text: t[0] };
  }
  link(e) {
    let t = this.rules.inline.link.exec(e);
    if (t) {
      let n = t[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(n)) {
        if (!this.rules.other.endAngleBracket.test(n)) return;
        let i = $(n.slice(0, -1), "\\");
        if ((n.length - i.length) % 2 === 0) return;
      } else {
        let i = fe(t[2], "()");
        if (i === -2) return;
        if (i > -1) {
          let u = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + i;
          t[2] = t[2].substring(0, i), t[0] = t[0].substring(0, u).trim(), t[3] = "";
        }
      }
      let s = t[2], r = "";
      if (this.options.pedantic) {
        let i = this.rules.other.pedanticHrefTitle.exec(s);
        i && (s = i[1], r = i[3]);
      } else r = t[3] ? t[3].slice(1, -1) : "";
      return s = s.trim(), this.rules.other.startAngleBracket.test(s) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(n) ? s = s.slice(1) : s = s.slice(1, -1)), xe(t, { href: s && s.replace(this.rules.inline.anyPunctuation, "$1"), title: r && r.replace(this.rules.inline.anyPunctuation, "$1") }, t[0], this.lexer, this.rules);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      let s = (n[2] || n[1]).replace(this.rules.other.multipleSpaceGlobal, " "), r = t[s.toLowerCase()];
      if (!r) {
        let i = n[0].charAt(0);
        return { type: "text", raw: i, text: i };
      }
      return xe(n, r, n[0], this.lexer, this.rules);
    }
  }
  emStrong(e, t, n = "") {
    let s = this.rules.inline.emStrongLDelim.exec(e);
    if (!s || !s[1] && !s[2] && !s[3] && !s[4] || s[4] && n.match(this.rules.other.unicodeAlphaNumeric)) return;
    if (!(s[1] || s[3] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      let i = [...s[0]].length - 1, o, u, a = i, p = 0, c = s[0][0], h = n === c, d = c === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + i); (s = d.exec(t)) !== null; ) {
        if (o = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !o) continue;
        if (u = [...o].length, s[3] || s[4]) {
          a += u;
          continue;
        } else if (s[5] || s[6]) {
          if (i % 3 && !((i + u) % 3)) {
            p += u;
            continue;
          }
          if (h) break;
        }
        if (a -= u, a > 0) continue;
        u = Math.min(u, u + a + p);
        let O = [...s[0]][0].length, g = e.slice(0, i + s.index + O + u);
        if (Math.min(i, u) % 2) {
          let E = g.slice(1, -1);
          return { type: "em", raw: g, text: E, tokens: this.lexer.inlineTokens(E) };
        }
        let w = g.slice(2, -2);
        return { type: "strong", raw: g, text: w, tokens: this.lexer.inlineTokens(w) };
      }
    }
  }
  codespan(e) {
    let t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(this.rules.other.newLineCharGlobal, " "), s = this.rules.other.nonSpaceChar.test(n), r = this.rules.other.startingSpaceChar.test(n) && this.rules.other.endingSpaceChar.test(n);
      return s && r && (n = n.substring(1, n.length - 1)), { type: "codespan", raw: t[0], text: n };
    }
  }
  br(e) {
    let t = this.rules.inline.br.exec(e);
    if (t) return { type: "br", raw: t[0] };
  }
  del(e, t, n = "") {
    let s = this.rules.inline.delLDelim.exec(e);
    if (!s) return;
    if (!(s[1] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      let i = [...s[0]].length - 1, o, u, a = i, p = this.rules.inline.delRDelim;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + i); (s = p.exec(t)) !== null; ) {
        if (o = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !o || (u = [...o].length, u !== i)) continue;
        if (s[3] || s[4]) {
          a += u;
          continue;
        }
        if (a -= u, a > 0) continue;
        u = Math.min(u, u + a);
        let c = [...s[0]][0].length, h = e.slice(0, i + s.index + c + u), d = h.slice(i, -i);
        return { type: "del", raw: h, text: d, tokens: this.lexer.inlineTokens(d) };
      }
    }
  }
  autolink(e) {
    let t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, s;
      return t[2] === "@" ? (n = t[1], s = "mailto:" + n) : (n = t[1], s = n), { type: "link", raw: t[0], text: n, href: s, tokens: [{ type: "text", raw: n, text: n }] };
    }
  }
  url(e) {
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let n, s;
      if (t[2] === "@") n = t[0], s = "mailto:" + n;
      else {
        let r;
        do
          r = t[0], t[0] = this.rules.inline._backpedal.exec(t[0])?.[0] ?? "";
        while (r !== t[0]);
        n = t[0], t[1] === "www." ? s = "http://" + t[0] : s = t[0];
      }
      return { type: "link", raw: t[0], text: n, href: s, tokens: [{ type: "text", raw: n, text: n }] };
    }
  }
  inlineText(e) {
    let t = this.rules.inline.text.exec(e);
    if (t) {
      let n = this.lexer.state.inRawBlock;
      return { type: "text", raw: t[0], text: t[0], escaped: n };
    }
  }
};
var x = class l {
  tokens;
  options;
  state;
  inlineQueue;
  tokenizer;
  constructor(e) {
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || R, this.options.tokenizer = this.options.tokenizer || new y(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: false, inRawBlock: false, linkEmitted: false, top: true };
    let t = { other: m, block: H.normal, inline: B.normal };
    this.options.pedantic ? (t.block = H.pedantic, t.inline = B.pedantic) : this.options.gfm && (t.block = H.gfm, this.options.breaks ? t.inline = B.breaks : t.inline = B.gfm), this.tokenizer.rules = t;
  }
  static get rules() {
    return { block: H, inline: B };
  }
  static lex(e, t) {
    return new l(t).lex(e);
  }
  static lexInline(e, t) {
    return new l(t).inlineTokens(e);
  }
  lex(e) {
    e = e.replace(m.carriageReturn, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      let n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = [], n = false) {
    this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(m.tabCharGlobal, "    ").replace(m.spaceLine, ""));
    let s = 1 / 0;
    for (; e; ) {
      if (e.length < s) s = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      let r;
      if (this.options.extensions?.block?.some((o) => (r = o.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), true) : false)) continue;
      if (r = this.tokenizer.space(e)) {
        e = e.substring(r.raw.length);
        let o = t.at(-1);
        r.raw.length === 1 && o !== void 0 ? o.raw += `
` : t.push(r);
        continue;
      }
      if (r = this.tokenizer.code(e)) {
        e = e.substring(r.raw.length);
        let o = t.at(-1);
        o?.type === "paragraph" || o?.type === "text" ? (o.raw += (o.raw.endsWith(`
`) ? "" : `
`) + r.raw, o.text += `
` + r.text, this.inlineQueue.at(-1).src = o.text) : t.push(r);
        continue;
      }
      if (r = this.tokenizer.fences(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.heading(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.hr(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.blockquote(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.list(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.html(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.def(e)) {
        e = e.substring(r.raw.length);
        let o = t.at(-1);
        o?.type === "paragraph" || o?.type === "text" ? (o.raw += (o.raw.endsWith(`
`) ? "" : `
`) + r.raw, o.text += `
` + r.raw, this.inlineQueue.at(-1).src = o.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = { href: r.href, title: r.title }, t.push(r));
        continue;
      }
      if (r = this.tokenizer.table(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      if (r = this.tokenizer.lheading(e)) {
        e = e.substring(r.raw.length), t.push(r);
        continue;
      }
      let i = e;
      if (this.options.extensions?.startBlock) {
        let o = 1 / 0, u = e.slice(1), a;
        this.options.extensions.startBlock.forEach((p) => {
          a = p.call({ lexer: this }, u), typeof a == "number" && a >= 0 && (o = Math.min(o, a));
        }), o < 1 / 0 && o >= 0 && (i = e.substring(0, o + 1));
      }
      if (this.state.top && (r = this.tokenizer.paragraph(i))) {
        let o = t.at(-1);
        n && o?.type === "paragraph" ? (o.raw += (o.raw.endsWith(`
`) ? "" : `
`) + r.raw, o.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = o.text) : t.push(r), n = i.length !== e.length, e = e.substring(r.raw.length);
        continue;
      }
      if (r = this.tokenizer.text(e)) {
        e = e.substring(r.raw.length);
        let o = t.at(-1);
        o?.type === "text" ? (o.raw += (o.raw.endsWith(`
`) ? "" : `
`) + r.raw, o.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = o.text) : t.push(r);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return this.state.top = true, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  linkInText(e) {
    if (!e.includes("[")) return false;
    let t = this.tokenizer.rules.inline.link;
    for (let n of e.matchAll(this.tokenizer.rules.inline.blockSkip)) if (t.test(n[0]) && e.charAt(n.index - 1) !== "!") return true;
    for (let n of e.matchAll(this.tokenizer.rules.inline.reflinkSearch)) {
      let s = n[0], r = s.lastIndexOf("[");
      if (!(s.charAt(0) === "!" || !Object.hasOwn(this.tokens.links, s.slice(r + 1, -1))) && !(r > 1 && this.linkInText(s.slice(1, r - 1)))) return true;
    }
    return false;
  }
  inlineTokens(e, t = []) {
    this.tokenizer.lexer = this;
    let n = e;
    if (this.tokens.links && e.includes("[")) {
      let o = this.tokenizer.rules.inline.reflinkSearch, u = (a) => {
        let p = a.lastIndexOf("[");
        if (!Object.hasOwn(this.tokens.links, a.slice(p + 1, -1))) return a;
        if (p > 1 && a.charAt(0) !== "!") {
          let c = a.slice(1, p - 1);
          if (this.linkInText(c)) return "[" + c.replace(o, u) + "][" + "a".repeat(a.length - p - 2) + "]";
        }
        return "[" + "a".repeat(a.length - 2) + "]";
      };
      n = n.replace(o, u);
    }
    n = n.replace(this.tokenizer.rules.inline.anyPunctuation, (o) => "+".repeat(o.length)), n = n.replace(this.tokenizer.rules.inline.blockSkip, (o, u, a) => {
      let p = a ? a.length : 0;
      return o.slice(0, p) + "[" + "a".repeat(o.length - p - 2) + "]";
    }), n = this.options.hooks?.emStrongMask?.call({ lexer: this }, n) ?? n;
    let s = false, r = "", i = 1 / 0;
    for (; e; ) {
      if (e.length < i) i = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      s || (r = ""), s = false;
      let o;
      if (this.options.extensions?.inline?.some((a) => (o = a.call({ lexer: this }, e, t)) ? (e = e.substring(o.raw.length), t.push(o), true) : false)) continue;
      if (o = this.tokenizer.escape(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.tag(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.link(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.reflink(e, this.tokens.links)) {
        e = e.substring(o.raw.length);
        let a = t.at(-1);
        o.type === "text" && a?.type === "text" ? (a.raw += o.raw, a.text += o.text) : t.push(o);
        continue;
      }
      if (o = this.tokenizer.emStrong(e, n, r)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.codespan(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.br(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.del(e, n, r)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (o = this.tokenizer.autolink(e)) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      if (!this.state.inLink && (o = this.tokenizer.url(e))) {
        e = e.substring(o.raw.length), t.push(o);
        continue;
      }
      let u = e;
      if (this.options.extensions?.startInline) {
        let a = 1 / 0, p = e.slice(1), c;
        this.options.extensions.startInline.forEach((h) => {
          c = h.call({ lexer: this }, p), typeof c == "number" && c >= 0 && (a = Math.min(a, c));
        }), a < 1 / 0 && a >= 0 && (u = e.substring(0, a + 1));
      }
      if (o = this.tokenizer.inlineText(u)) {
        e = e.substring(o.raw.length), o.raw.slice(-1) !== "_" && (r = o.raw.slice(-1)), s = true;
        let a = t.at(-1);
        a?.type === "text" ? (a.raw += o.raw, a.text += o.text) : t.push(o);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return t;
  }
  infiniteLoopError(e) {
    let t = "Infinite loop on byte: " + e;
    if (this.options.silent) console.error(t);
    else throw new Error(t);
  }
};
var P = class {
  options;
  parser;
  constructor(e) {
    this.options = e || R;
  }
  space(e) {
    return "";
  }
  code({ text: e, lang: t, escaped: n }) {
    let s = (t || "").match(m.notSpaceStart)?.[0], r = e.replace(m.endingNewline, "") + `
`;
    return s ? '<pre><code class="language-' + T(s) + '">' + (n ? r : T(r, true)) + `</code></pre>
` : "<pre><code>" + (n ? r : T(r, true)) + `</code></pre>
`;
  }
  blockquote({ tokens: e }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({ text: e }) {
    return e;
  }
  def(e) {
    return "";
  }
  heading({ tokens: e, depth: t }) {
    return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    let t = e.ordered, n = e.start, s = "";
    for (let o = 0; o < e.items.length; o++) {
      let u = e.items[o];
      s += this.listitem(u);
    }
    let r = t ? "ol" : "ul", i = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + r + i + `>
` + s + "</" + r + `>
`;
  }
  listitem(e) {
    return `<li>${this.parser.parse(e.tokens)}</li>
`;
  }
  checkbox({ checked: e }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"> ';
  }
  paragraph({ tokens: e }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let t = "", n = "";
    for (let r = 0; r < e.header.length; r++) n += this.tablecell(e.header[r]);
    t += this.tablerow({ text: n });
    let s = "";
    for (let r = 0; r < e.rows.length; r++) {
      let i = e.rows[r];
      n = "";
      for (let o = 0; o < i.length; o++) n += this.tablecell(i[o]);
      s += this.tablerow({ text: n });
    }
    return s && (s = `<tbody>${s}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + s + `</table>
`;
  }
  tablerow({ text: e }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    let t = this.parser.parseInline(e.tokens), n = e.header ? "th" : "td";
    return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
  }
  strong({ tokens: e }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({ tokens: e }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({ text: e }) {
    return `<code>${T(e, true)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({ tokens: e }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({ href: e, title: t, tokens: n }) {
    let s = this.parser.parseInline(n), r = Y(e);
    if (r === null) return s;
    e = r;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + T(t) + '"'), i += ">" + s + "</a>", i;
  }
  image({ href: e, title: t, text: n, tokens: s }) {
    s && (n = this.parser.parseInline(s, this.parser.textRenderer));
    let r = Y(e);
    if (r === null) return T(n);
    e = r;
    let i = `<img src="${e}" alt="${T(n)}"`;
    return t && (i += ` title="${T(t)}"`), i += ">", i;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : T(e.text);
  }
};
var L = class {
  strong({ text: e }) {
    return e;
  }
  em({ text: e }) {
    return e;
  }
  codespan({ text: e }) {
    return e;
  }
  del({ text: e }) {
    return e;
  }
  html({ text: e }) {
    return e;
  }
  text({ text: e }) {
    return e;
  }
  link({ text: e }) {
    return "" + e;
  }
  image({ text: e }) {
    return "" + e;
  }
  br() {
    return "";
  }
  checkbox({ raw: e }) {
    return e;
  }
};
var b = class l2 {
  options;
  renderer;
  textRenderer;
  constructor(e) {
    this.options = e || R, this.options.renderer = this.options.renderer || new P(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new L();
  }
  static parse(e, t) {
    return new l2(t).parse(e);
  }
  static parseInline(e, t) {
    return new l2(t).parseInline(e);
  }
  parse(e) {
    this.renderer.parser = this;
    let t = "";
    for (let n = 0; n < e.length; n++) {
      let s = e[n];
      if (this.options.extensions?.renderers?.[s.type]) {
        let i = s, o = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (o !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "checkbox", "html", "def", "paragraph", "text"].includes(i.type)) {
          t += o || "";
          continue;
        }
      }
      let r = s;
      switch (r.type) {
        case "space": {
          t += this.renderer.space(r);
          break;
        }
        case "hr": {
          t += this.renderer.hr(r);
          break;
        }
        case "heading": {
          t += this.renderer.heading(r);
          break;
        }
        case "code": {
          t += this.renderer.code(r);
          break;
        }
        case "table": {
          t += this.renderer.table(r);
          break;
        }
        case "blockquote": {
          t += this.renderer.blockquote(r);
          break;
        }
        case "list": {
          t += this.renderer.list(r);
          break;
        }
        case "checkbox": {
          t += this.renderer.checkbox(r);
          break;
        }
        case "html": {
          t += this.renderer.html(r);
          break;
        }
        case "def": {
          t += this.renderer.def(r);
          break;
        }
        case "paragraph": {
          t += this.renderer.paragraph(r);
          break;
        }
        case "text": {
          t += this.renderer.text(r);
          break;
        }
        default: {
          let i = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent) return console.error(i), "";
          throw new Error(i);
        }
      }
    }
    return t;
  }
  parseInline(e, t = this.renderer) {
    this.renderer.parser = this;
    let n = "";
    for (let s = 0; s < e.length; s++) {
      let r = e[s];
      if (this.options.extensions?.renderers?.[r.type]) {
        let o = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (o !== false || !["escape", "html", "link", "image", "checkbox", "strong", "em", "codespan", "br", "del", "text"].includes(r.type)) {
          n += o || "";
          continue;
        }
      }
      let i = r;
      switch (i.type) {
        case "escape": {
          n += t.text(i);
          break;
        }
        case "html": {
          n += t.html(i);
          break;
        }
        case "link": {
          n += t.link(i);
          break;
        }
        case "image": {
          n += t.image(i);
          break;
        }
        case "checkbox": {
          n += t.checkbox(i);
          break;
        }
        case "strong": {
          n += t.strong(i);
          break;
        }
        case "em": {
          n += t.em(i);
          break;
        }
        case "codespan": {
          n += t.codespan(i);
          break;
        }
        case "br": {
          n += t.br(i);
          break;
        }
        case "del": {
          n += t.del(i);
          break;
        }
        case "text": {
          n += t.text(i);
          break;
        }
        default: {
          let o = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
};
var S = class {
  options;
  block;
  constructor(e) {
    this.options = e || R;
  }
  static passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
  static passThroughHooksRespectAsync = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"]);
  preprocess(e) {
    return e;
  }
  postprocess(e) {
    return e;
  }
  processAllTokens(e) {
    return e;
  }
  emStrongMask(e) {
    return e;
  }
  provideLexer(e = this.block) {
    return e ? x.lex : x.lexInline;
  }
  provideParser(e = this.block) {
    return e ? b.parse : b.parseInline;
  }
};
var Z = class {
  defaults = A();
  options = this.setOptions;
  parse = this.parseMarkdown(true);
  parseInline = this.parseMarkdown(false);
  Parser = b;
  Renderer = P;
  TextRenderer = L;
  Lexer = x;
  Tokenizer = y;
  Hooks = S;
  constructor(...e) {
    this.use(...e);
  }
  walkTokens(e, t) {
    let n = [];
    for (let s of e) switch (n = n.concat(t.call(this, s)), s.type) {
      case "table": {
        let r = s;
        for (let i of r.header) n = n.concat(this.walkTokens(i.tokens, t));
        for (let i of r.rows) for (let o of i) n = n.concat(this.walkTokens(o.tokens, t));
        break;
      }
      case "list": {
        let r = s;
        n = n.concat(this.walkTokens(r.items, t));
        break;
      }
      default: {
        let r = s;
        this.defaults.extensions?.childTokens?.[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((i) => {
          let o = r[i].flat(1 / 0);
          n = n.concat(this.walkTokens(o, t));
        }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
      }
    }
    return n;
  }
  use(...e) {
    let t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      let s = { ...n };
      if (s.async = this.defaults.async || s.async || false, n.extensions && (n.extensions.forEach((r) => {
        if (!r.name) throw new Error("extension name required");
        if ("renderer" in r) {
          let i = t.renderers[r.name];
          i ? t.renderers[r.name] = function(...o) {
            let u = r.renderer.apply(this, o);
            return u === false && (u = i.apply(this, o)), u;
          } : t.renderers[r.name] = r.renderer;
        }
        if ("tokenizer" in r) {
          if (!r.level || r.level !== "block" && r.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let i = t[r.level];
          i ? i.unshift(r.tokenizer) : t[r.level] = [r.tokenizer], r.start && (r.level === "block" ? t.startBlock ? t.startBlock.push(r.start) : t.startBlock = [r.start] : r.level === "inline" && (t.startInline ? t.startInline.push(r.start) : t.startInline = [r.start]));
        }
        "childTokens" in r && r.childTokens && (t.childTokens[r.name] = r.childTokens);
      }), s.extensions = t), n.renderer) {
        let r = this.defaults.renderer || new P(this.defaults);
        for (let i in n.renderer) {
          if (!(i in r)) throw new Error(`renderer '${i}' does not exist`);
          if (["options", "parser"].includes(i)) continue;
          let o = i, u = n.renderer[o], a = r[o];
          r[o] = (...p) => {
            let c = u.apply(r, p);
            return c === false && (c = a.apply(r, p)), c || "";
          };
        }
        s.renderer = r;
      }
      if (n.tokenizer) {
        let r = this.defaults.tokenizer || new y(this.defaults);
        for (let i in n.tokenizer) {
          if (!(i in r)) throw new Error(`tokenizer '${i}' does not exist`);
          if (["options", "rules", "lexer"].includes(i)) continue;
          let o = i, u = n.tokenizer[o], a = r[o];
          r[o] = (...p) => {
            let c = u.apply(r, p);
            return c === false && (c = a.apply(r, p)), c;
          };
        }
        s.tokenizer = r;
      }
      if (n.hooks) {
        let r = this.defaults.hooks || new S();
        for (let i in n.hooks) {
          if (!(i in r)) throw new Error(`hook '${i}' does not exist`);
          if (["options", "block"].includes(i)) continue;
          let o = i, u = n.hooks[o], a = r[o];
          S.passThroughHooks.has(i) ? r[o] = (p) => {
            if (this.defaults.async && S.passThroughHooksRespectAsync.has(i)) return (async () => {
              let h = await u.call(r, p);
              return a.call(r, h);
            })();
            let c = u.call(r, p);
            return a.call(r, c);
          } : r[o] = (...p) => {
            if (this.defaults.async) return (async () => {
              let h = await u.apply(r, p);
              return h === false && (h = await a.apply(r, p)), h;
            })();
            let c = u.apply(r, p);
            return c === false && (c = a.apply(r, p)), c;
          };
        }
        s.hooks = r;
      }
      if (n.walkTokens) {
        let r = this.defaults.walkTokens, i = n.walkTokens;
        s.walkTokens = function(o) {
          let u = [];
          return u.push(i.call(this, o)), r && (u = u.concat(r.call(this, o))), u;
        };
      }
      this.defaults = { ...this.defaults, ...s };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return x.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return b.parse(e, t ?? this.defaults);
  }
  parseMarkdown(e) {
    return (n, s) => {
      let r = { ...s }, i = { ...this.defaults, ...r }, o = this.onError(!!i.silent, !!i.async);
      if (this.defaults.async === true && r.async === false) return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof n > "u" || n === null) return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof n != "string") return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
      if (i.hooks && (i.hooks.options = i, i.hooks.block = e), i.async) return (async () => {
        let u = i.hooks ? await i.hooks.preprocess(n) : n, p = await (i.hooks ? await i.hooks.provideLexer(e) : e ? x.lex : x.lexInline)(u, i), c = i.hooks ? await i.hooks.processAllTokens(p) : p;
        i.walkTokens && await Promise.all(this.walkTokens(c, i.walkTokens));
        let d = await (i.hooks ? await i.hooks.provideParser(e) : e ? b.parse : b.parseInline)(c, i);
        return i.hooks ? await i.hooks.postprocess(d) : d;
      })().catch(o);
      try {
        i.hooks && (n = i.hooks.preprocess(n));
        let a = (i.hooks ? i.hooks.provideLexer(e) : e ? x.lex : x.lexInline)(n, i);
        i.hooks && (a = i.hooks.processAllTokens(a)), i.walkTokens && this.walkTokens(a, i.walkTokens);
        let c = (i.hooks ? i.hooks.provideParser(e) : e ? b.parse : b.parseInline)(a, i);
        return i.hooks && (c = i.hooks.postprocess(c)), c;
      } catch (u) {
        return o(u);
      }
    };
  }
  onError(e, t) {
    return (n) => {
      if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        let s = "<p>An error occurred:</p><pre>" + T(n.message + "", true) + "</pre>";
        return t ? Promise.resolve(s) : s;
      }
      if (t) return Promise.reject(n);
      throw n;
    };
  }
};
var M = new Z();
function f(l3, e) {
  return M.parse(l3, e);
}
f.options = f.setOptions = function(l3) {
  return M.setOptions(l3), f.defaults = M.defaults, j(f.defaults), f;
};
f.getDefaults = A;
f.defaults = R;
function dt(...l3) {
  return M.use(...l3), f.defaults = M.defaults, j(f.defaults), f;
}
f.use = dt;
f.walkTokens = function(l3, e) {
  return M.walkTokens(l3, e);
};
f.parseInline = M.parseInline;
f.Parser = b;
f.parser = b.parse;
f.Renderer = P;
f.TextRenderer = L;
f.Lexer = x;
f.lexer = x.lex;
f.Tokenizer = y;
f.Hooks = S;
f.parse = f;
var nn = f.options;
var rn = f.setOptions;
var sn = f.walkTokens;
var on = f.parseInline;
var ln = b.parse;
var un = x.lex;

// src/targets/csdn-api.ts
var API = "https://bizapi.csdn.net/blog-console-api/v3/mdeditor/saveArticle";
var CSDN_WEB_API_KEY = "203803574";
var CSDN_WEB_SIGNING_KEY = "9znpamsyl2c7cdrr9sas0le9vbc3r6ba";
function validateCsdnArticle(article) {
  const title = article.title.trim();
  if (title.length < 5) throw new SyncError("CSDN \u6807\u9898\u81F3\u5C11\u9700\u8981 5 \u4E2A\u5B57\u7B26\uFF0C\u8BF7\u4FEE\u6539\u6398\u91D1\u6807\u9898\u540E\u91CD\u65B0\u540C\u6B65", "content", "validation");
  if (title.length > 100) throw new SyncError("CSDN \u6807\u9898\u6700\u591A\u5141\u8BB8 100 \u4E2A\u5B57\u7B26\uFF0C\u8BF7\u7F29\u77ED\u6398\u91D1\u6807\u9898\u540E\u91CD\u65B0\u540C\u6B65", "content", "validation");
  if (article.markdown.trim().length < 20) throw new SyncError("\u6587\u7AE0\u6B63\u6587\u4E0D\u5B8C\u6574\uFF0C\u6682\u65E0\u6CD5\u540C\u6B65\u5230 CSDN", "content", "validation");
}
function statusErrorCategory(status) {
  if (status === 401) return "login";
  if (status === 429) return "rate-limit";
  if (status >= 500) return "network";
  return void 0;
}
function nonce() {
  return crypto.randomUUID();
}
async function hmacSha256(message) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", encoder.encode(CSDN_WEB_SIGNING_KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}
async function signedHeaders(path, method) {
  const requestNonce = nonce();
  const signText = method === "GET" ? `GET
*/*



x-ca-key:${CSDN_WEB_API_KEY}
x-ca-nonce:${requestNonce}
${path}` : `POST
*/*

application/json

x-ca-key:${CSDN_WEB_API_KEY}
x-ca-nonce:${requestNonce}
${path}`;
  const headers = { accept: "*/*", "x-ca-key": CSDN_WEB_API_KEY, "x-ca-nonce": requestNonce, "x-ca-signature": await hmacSha256(signText), "x-ca-signature-headers": "x-ca-key,x-ca-nonce" };
  if (method === "POST") headers["content-type"] = "application/json";
  return headers;
}
async function checkCsdnAuth() {
  const path = "/blog-console-api/v3/editor/getBaseInfo";
  try {
    const response = await fetch(`https://bizapi.csdn.net${path}`, { method: "GET", credentials: "include", headers: await signedHeaders(path, "GET"), signal: AbortSignal.timeout(6e3) });
    if (response.status === 401) return { ok: true, loggedIn: false };
    if (!response.ok) {
      const detail = response.headers.get("x-ca-error-message") || await response.text().catch(() => "");
      return { ok: false, loggedIn: false, message: `CSDN \u63A5\u53E3\u9274\u6743\u5F02\u5E38 (${response.status})${detail ? `\uFF1A${detail.slice(0, 120)}` : ""}` };
    }
    const result = await response.json();
    const loggedIn = result.code === 200 && !!result.data?.name;
    return { ok: true, loggedIn, account: loggedIn ? result.data?.nickname || result.data?.name : void 0 };
  } catch (error) {
    return { ok: false, loggedIn: false, message: error.message || "CSDN \u767B\u5F55\u72B6\u6001\u68C0\u6D4B\u5931\u8D25" };
  }
}
async function fetchCsdnCategories() {
  const path = "/blog-console-api/v3/editor/getBaseInfo";
  try {
    const response = await fetch(`https://bizapi.csdn.net${path}`, { method: "GET", credentials: "include", headers: await signedHeaders(path, "GET"), signal: AbortSignal.timeout(6e3) });
    if (response.status === 401) return { ok: false, categories: [], message: "\u8BF7\u5148\u767B\u5F55 CSDN" };
    if (!response.ok) return { ok: false, categories: [], message: `CSDN \u63A5\u53E3\u5F02\u5E38 (${response.status})` };
    const result = await response.json();
    if (result.code !== 200) return { ok: false, categories: [], message: "CSDN \u8FD4\u56DE\u9519\u8BEF\u7801 " + result.code };
    const raw = result.data?.categorys ?? result.data?.categories;
    const categories = (Array.isArray(raw) ? raw : []).filter((item) => typeof item === "string" && item.trim().length > 0).map((item) => item.trim());
    return { ok: true, categories };
  } catch (error) {
    return { ok: false, categories: [], message: error.message || "CSDN \u5206\u7C7B\u5217\u8868\u62C9\u53D6\u5931\u8D25" };
  }
}
async function fetchCsdnArticleState(articleId) {
  const path = `/blog-console-api/v3/editor/getArticle?id=${encodeURIComponent(articleId)}`;
  try {
    const response = await fetch(`https://bizapi.csdn.net${path}`, { method: "GET", credentials: "include", headers: await signedHeaders(path, "GET"), signal: AbortSignal.timeout(8e3) });
    if (!response.ok) return "unknown";
    const result = await response.json();
    if (result.code !== 200 || !result.data) return "unknown";
    if (typeof result.data.pubStatus === "string" && result.data.pubStatus) return result.data.pubStatus === "draft" ? "draft" : "published";
    if (typeof result.data.status === "number") return result.data.status === 2 ? "draft" : "published";
    return "unknown";
  } catch {
    return "unknown";
  }
}
var CONTAINER_KINDS = {
  tips: { emoji: "\u{1F4A1}", label: "\u63D0\u793A" },
  info: { emoji: "\u2139\uFE0F", label: "\u8BF4\u660E" },
  note: { emoji: "\u{1F4DD}", label: "\u7B14\u8BB0" },
  warning: { emoji: "\u26A0\uFE0F", label: "\u6CE8\u610F" },
  danger: { emoji: "\u{1F6A8}", label: "\u8B66\u544A" },
  success: { emoji: "\u2705", label: "\u6210\u529F" }
};
function sanitizeJuejinContainers(markdown) {
  const lines = markdown.split("\n");
  const output = [];
  let inFence = false;
  let fenceMarker = "";
  let container = null;
  const flushContainer = () => {
    if (!container) return;
    output.push(container.header);
    output.push(...container.body.length ? container.body : [">"]);
    container = null;
  };
  for (const line of lines) {
    if (container) {
      if (/^ {0,3}:::[ \t]*$/.test(line)) {
        flushContainer();
        continue;
      }
      container.body.push(line.trim() ? `> ${line}` : ">");
      continue;
    }
    const fence = line.match(/^ {0,3}(`{3,}|~{3,})/);
    if (fence) {
      if (!inFence) {
        inFence = true;
        fenceMarker = fence[1][0];
      } else if (fence[1][0] === fenceMarker) {
        inFence = false;
        fenceMarker = "";
      }
      output.push(line);
      continue;
    }
    if (!inFence) {
      const open = line.match(/^ {0,3}:::[ \t]*([A-Za-z\u4e00-\u9fa5][\w\u4e00-\u9fa5-]*)?[ \t]*(.*)$/);
      if (open && open[1]) {
        const meta = CONTAINER_KINDS[open[1].toLowerCase()] || { emoji: "\u2139\uFE0F", label: open[1] };
        container = { header: `> ${meta.emoji} ${meta.label}\uFF1A${open[2].trim()}`, body: [] };
        continue;
      }
    }
    output.push(line);
  }
  flushContainer();
  return output.join("\n");
}
function countJuejinContainers(markdown) {
  let inFence = false;
  let fenceMarker = "";
  let count = 0;
  for (const line of markdown.split("\n")) {
    const fence = line.match(/^ {0,3}(`{3,}|~{3,})/);
    if (fence) {
      if (!inFence) {
        inFence = true;
        fenceMarker = fence[1][0];
      } else if (fence[1][0] === fenceMarker) {
        inFence = false;
        fenceMarker = "";
      }
      continue;
    }
    if (!inFence && /^ {0,3}:::[ \t]*[A-Za-z\u4e00-\u9fa5][\w\u4e00-\u9fa5-]*[ \t]*(.*)$/.test(line)) count++;
  }
  return count;
}
function countCodeFences(markdown) {
  let count = 0;
  let inFence = false;
  let fenceMarker = "";
  for (const line of markdown.split("\n")) {
    const fence = line.match(/^ {0,3}(`{3,}|~{3,})/);
    if (!fence) continue;
    if (!inFence) {
      inFence = true;
      fenceMarker = fence[1][0];
      count++;
    } else if (fence[1][0] === fenceMarker) {
      inFence = false;
      fenceMarker = "";
    }
  }
  return count;
}
function extractSummary(markdown, limit = 100) {
  const text = markdown.replace(/```[\s\S]*?```/g, " ").replace(/~~~[\s\S]*?~~~/g, " ").replace(/`([^`]*)`/g, "$1").replace(/!\[[^\]]*\]\([^)]*\)/g, " ").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/<[^>]+>/g, " ").replace(/^\s{0,3}(#{1,6}|>|[-*+]|\d+\.)\s?/gm, " ").replace(/^\s{0,3}\|.*\|\s*$/gm, " ").replace(/[*_~]{1,3}/g, "").replace(/\s+/g, " ").trim();
  return text.length <= limit ? text : text.slice(0, limit);
}
function buildSourceAttribution(article) {
  const url = article.sourceUrl?.trim();
  if (!url) return "";
  const title = article.title?.trim();
  return `

---

> \u672C\u6587\u9996\u53D1\u4E8E\u6398\u91D1${title ? `\uFF1A[${title}](${url})` : `\uFF1A${url}`}`;
}
function stripJuejinImageParams(src) {
  try {
    const url = new URL(src);
    if (!/(^|\.)((juejin\.cn)|(byteimg\.com)|(bytecdn\.cn))$/i.test(url.hostname)) return src;
    let changed = false;
    const tplvIndex = url.pathname.indexOf("~tplv-");
    if (tplvIndex > 0) {
      url.pathname = url.pathname.slice(0, tplvIndex);
      changed = true;
    }
    if (url.searchParams.has("x-oss-process")) {
      url.searchParams.delete("x-oss-process");
      changed = true;
    }
    return changed ? url.toString() : src;
  } catch {
    return src;
  }
}
function normalizeMarkdown(source) {
  let markdown = source.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  const frontmatter = markdown.match(/^---[ \t]*\n([\s\S]*?)\n---[ \t]*(?:\n|$)/);
  if (frontmatter && /^(?:theme|highlight)\s*:/m.test(frontmatter[1])) markdown = markdown.slice(frontmatter[0].length);
  markdown = markdown.replace(/^(?:(?:theme|highlight)\s*:[^\n]*\n){1,2}(?:\n)?/, "");
  markdown = markdown.replace(/^(\s*)~~~([^\n]*)$/gm, "$1```$2");
  markdown = sanitizeJuejinContainers(markdown);
  return markdown.trim();
}
function imageExtension(src, blob) {
  const pathExtension = src.match(/\.([a-zA-Z0-9]+)(?:[?#]|$)/)?.[1]?.toLowerCase();
  if (pathExtension && ["jpg", "jpeg", "png", "gif", "webp"].includes(pathExtension)) return pathExtension;
  const mimeExtension = { "image/jpeg": "jpg", "image/png": "png", "image/gif": "gif", "image/webp": "webp" };
  return mimeExtension[blob.type.toLowerCase()] || "jpg";
}
async function downloadImageBlob(src) {
  const hostname = new URL(src).hostname;
  const credentials = hostname.endsWith("-private.juejin.cn") ? "include" : "omit";
  const direct = stripJuejinImageParams(src);
  const attempts = direct !== src ? [direct, src] : [src];
  let lastError;
  for (const url of attempts) {
    try {
      const imageResponse = await fetch(url, { credentials });
      if (!imageResponse.ok) {
        lastError = new SyncError(`\u56FE\u7247\u4E0B\u8F7D\u5931\u8D25 (${imageResponse.status})\uFF1A${src}`, statusErrorCategory(imageResponse.status) ?? "content", "images");
        continue;
      }
      const imageBlob = await imageResponse.blob();
      if (!imageBlob.type.startsWith("image/")) throw new SyncError(`\u56FE\u7247\u5730\u5740\u8FD4\u56DE\u4E86\u975E\u56FE\u7247\u5185\u5BB9\uFF1A${src}`, "content", "images");
      return imageBlob;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new SyncError(`\u56FE\u7247\u4E0B\u8F7D\u5931\u8D25\uFF1A${src}`, "network", "images");
}
async function uploadImageToCsdn(src) {
  const imageBlob = await downloadImageBlob(src);
  const extension = imageExtension(src, imageBlob);
  const signaturePath = "/resource-api/v1/image/direct/upload/signature";
  const signatureResponse = await fetch(`https://bizapi.csdn.net${signaturePath}`, { method: "POST", credentials: "include", headers: await signedHeaders(signaturePath, "POST"), body: JSON.stringify({ imageTemplate: "", appName: "direct_blog_markdown", imageSuffix: extension }) });
  if (!signatureResponse.ok) throw new SyncError(`\u83B7\u53D6 CSDN \u56FE\u7247\u4E0A\u4F20\u51ED\u8BC1\u5931\u8D25 (${signatureResponse.status})`, statusErrorCategory(signatureResponse.status) ?? "platform-change", "images");
  const signatureResult = await signatureResponse.json();
  if (signatureResult.code !== 200 || !signatureResult.data) throw new SyncError(signatureResult.msg || signatureResult.message || "\u83B7\u53D6 CSDN \u56FE\u7247\u4E0A\u4F20\u51ED\u8BC1\u5931\u8D25", "platform-change", "images");
  const upload = signatureResult.data;
  const custom = upload.customParam;
  const form = new FormData();
  form.append("key", upload.filePath);
  form.append("policy", upload.policy);
  form.append("signature", upload.signature);
  form.append("callbackBody", upload.callbackBody);
  form.append("callbackBodyType", upload.callbackBodyType);
  form.append("callbackUrl", upload.callbackUrl);
  form.append("AccessKeyId", upload.accessId);
  form.append("x:rtype", custom.rtype);
  form.append("x:filePath", custom.filePath);
  form.append("x:isAudit", String(custom.isAudit));
  form.append("x:x-image-app", custom["x-image-app"]);
  form.append("x:type", custom.type);
  form.append("x:x-image-suffix", custom["x-image-suffix"]);
  form.append("x:username", custom.username);
  form.append("file", imageBlob, `image.${extension}`);
  const uploadResponse = await fetch(upload.host, { method: "POST", body: form });
  if (!uploadResponse.ok) throw new SyncError(`\u4E0A\u4F20\u56FE\u7247\u5230 CSDN \u5931\u8D25 (${uploadResponse.status})`, statusErrorCategory(uploadResponse.status) ?? "network", "images");
  const uploadResult = await uploadResponse.json();
  if (uploadResult.code !== 200 || !uploadResult.data?.imageUrl) throw new SyncError(uploadResult.msg || uploadResult.message || "\u4E0A\u4F20\u56FE\u7247\u5230 CSDN \u5931\u8D25", "platform-change", "images");
  return uploadResult.data.imageUrl;
}
function collectExternalImages(markdown) {
  const urls = /* @__PURE__ */ new Set();
  const markdownImage = /!\[[^\]]*\]\(\s*(?:<([^>]+)>|([^\s)]+))/g;
  const htmlImage = /<img\b[^>]*\bsrc=["']([^"']+)["']/gi;
  for (const match of markdown.matchAll(markdownImage)) urls.add(match[1] || match[2]);
  for (const match of markdown.matchAll(htmlImage)) urls.add(match[1]);
  return [...urls].filter((src) => {
    try {
      const url = new URL(src);
      return /^https?:$/.test(url.protocol) && !/(?:^|\.)csdn\.net$|(?:^|\.)csdnimg\.cn$/i.test(url.hostname);
    } catch {
      return false;
    }
  });
}
function summarizeImageTransfers(transfers) {
  return { imageTotal: transfers.length, imageSucceeded: transfers.filter((item) => item.target).length, imageFailed: transfers.filter((item) => item.error).length };
}
function enforceImageFailurePolicy(transfers, policy = "continue") {
  const failed = transfers.filter((item) => item.error);
  if (policy === "abort" && failed.length) throw new SyncError(`\u6709 ${failed.length} \u5F20\u56FE\u7247\u8F6C\u5B58\u5931\u8D25\uFF0C\u5DF2\u6309\u8BBE\u7F6E\u7EC8\u6B62\u540C\u6B65\uFF1A${failed[0].error}`, failed[0].errorCategory ?? "content", "images");
}
function applyImageTransfers(markdown, cover, transfers) {
  const replacements = new Map(transfers.filter((item) => item.target).map((item) => [item.src, item.target]));
  for (const [src, target] of replacements) markdown = markdown.split(src).join(target);
  const warnings = transfers.filter((item) => item.error).map((item) => {
    const location = cover === item.src && !markdown.includes(item.src) ? "\u5C01\u9762" : "\u6B63\u6587\u56FE\u7247";
    const action = location === "\u5C01\u9762" ? "\u5DF2\u5FFD\u7565" : "\u5DF2\u4FDD\u7559\u539F\u94FE\u63A5";
    return `${location}\u8F6C\u5B58\u5931\u8D25\uFF0C${action}\uFF1A${item.src}\uFF08${item.error}\uFF09`;
  });
  return { markdown, cover: cover ? replacements.get(cover) : void 0, warnings };
}
async function prepareArticle(article, options) {
  let markdown = normalizeMarkdown(article.markdown);
  const summary = article.summary?.trim() || extractSummary(markdown);
  if (options.appendSourceLink !== false) markdown += buildSourceAttribution(article);
  const images = collectExternalImages(markdown);
  const cover = options.syncCover === false ? void 0 : article.cover;
  if (cover && !images.includes(cover)) images.push(cover);
  let completed = 0;
  if (images.length) await options.onProgress?.({ current: 0, total: images.length, message: `\u51C6\u5907\u8F6C\u5B58 ${images.length} \u5F20\u56FE\u7247` });
  const transfers = await mapConcurrent(images, 3, async (src) => {
    let result;
    try {
      result = { src, target: await retry(() => uploadImageToCsdn(src)) };
    } catch (error) {
      result = { src, error: error.message, errorCategory: error instanceof SyncError ? error.category : void 0 };
    } finally {
      completed++;
      await options.onProgress?.({ current: completed, total: images.length, message: `\u6B63\u5728\u8F6C\u5B58\u56FE\u7247 ${completed}/${images.length}` });
    }
    return result;
  });
  enforceImageFailurePolicy(transfers, options.imageFailurePolicy);
  const transferred = applyImageTransfers(markdown, cover, transfers);
  const html = f.parse(transferred.markdown, { async: false, gfm: true, breaks: false });
  return { ...transferred, html, summary, stats: summarizeImageTransfers(transfers) };
}
function buildSaveArticleBody(article, prepared, articleId, categories = [], autoSummary = true) {
  return { title: article.title, markdowncontent: prepared.markdown + "\n", content: prepared.html + "\n", Description: autoSummary ? prepared.summary || "" : "", readType: "public", level: 0, tags: article.tags?.join(",") || "", status: 2, categories: [...new Set(categories.map((item) => item.trim()).filter(Boolean))].join(","), type: "original", original_link: "", authorized_status: false, not_auto_saved: "1", source: "pc_mdeditor", cover_images: prepared.cover ? [prepared.cover] : [], cover_type: prepared.cover ? 1 : 0, is_new: articleId ? 0 : 1, ...articleId ? { id: articleId } : {}, vote_id: 0, resource_id: "", pubStatus: "draft", creation_statement: 0, creator_activity_id: "" };
}
async function saveDraftViaApi(article, options = {}, prepared) {
  validateCsdnArticle(article);
  const auth = await checkCsdnAuth();
  if (!auth.ok) throw new SyncError(auth.message || "CSDN \u767B\u5F55\u72B6\u6001\u68C0\u6D4B\u5931\u8D25", "platform-change", "authentication");
  if (!auth.loggedIn) throw new SyncError("\u8BF7\u5148\u767B\u5F55 CSDN", "login", "authentication");
  await options.onPreparing?.();
  const preparedResult = prepared ?? await prepareArticle(article, options);
  const body = buildSaveArticleBody(article, preparedResult, options.articleId, options.categories, options.autoSummary !== false);
  await options.onSaving?.();
  const response = await fetch(API, { method: "POST", credentials: "include", headers: await signedHeaders("/blog-console-api/v3/mdeditor/saveArticle", "POST"), body: JSON.stringify(body) });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    if (response.status === 400 && options.articleId && text.includes("\u8BE5\u6587\u7AE0\u4E0D\u5B58\u5728")) return saveDraftViaApi(article, { ...options, articleId: void 0 }, preparedResult);
    throw new SyncError("CSDN API \u8BF7\u6C42\u5931\u8D25 (" + response.status + ")" + (text ? ": " + text.slice(0, 120) : ""), statusErrorCategory(response.status) ?? "platform-change", "draft");
  }
  const result = await response.json();
  if (result.code !== 200 && result.code !== 0) throw new SyncError(result.msg || result.message || "CSDN \u8FD4\u56DE\u9519\u8BEF\u7801 " + result.code, "platform-change", "draft");
  const articleId = result.data?.id || result.data?.article_id;
  const draftUrl = result.data?.url || (articleId ? "https://editor.csdn.net/md/?articleId=" + articleId : "");
  if (!draftUrl || !articleId) throw new SyncError("CSDN \u5DF2\u4FDD\u5B58\u8349\u7A3F\uFF0C\u4F46\u6CA1\u6709\u8FD4\u56DE\u8349\u7A3F\u6807\u8BC6", "platform-change", "draft");
  return { draftUrl, articleId: String(articleId), warnings: preparedResult.warnings, stats: preparedResult.stats };
}
function buildDryRunReport(article, settings) {
  const markdown = normalizeMarkdown(article.markdown);
  const rawMarkdown = article.markdown.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  const issues = [];
  const title = article.title.trim();
  if (title.length < 5) issues.push(`\u6807\u9898 ${title.length} \u5B57\uFF0C\u5C11\u4E8E CSDN \u8981\u6C42\u7684 5 \u5B57\u4E0B\u9650`);
  if (title.length > 100) issues.push(`\u6807\u9898 ${title.length} \u5B57\uFF0C\u8D85\u8FC7 CSDN \u7684 100 \u5B57\u4E0A\u9650`);
  if (markdown.length < 20) issues.push("\u6B63\u6587\u5185\u5BB9\u8FC7\u77ED\uFF0C\u4E0D\u6EE1\u8DB3\u540C\u6B65\u8981\u6C42");
  const images = collectExternalImages(markdown);
  if (images.length > 50) issues.push(`\u5916\u94FE\u56FE\u7247\u591A\u8FBE ${images.length} \u5F20\uFF0C\u8F6C\u5B58\u8017\u65F6\u8F83\u957F`);
  const categories = resolveCsdnCategories(article.tags, settings);
  if (!categories.length) issues.push("\u672A\u547D\u4E2D\u4EFB\u4F55 CSDN \u5206\u7C7B\uFF08\u53EF\u5728\u504F\u597D\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u9ED8\u8BA4\u5206\u7C7B\u6216\u6807\u7B7E\u6620\u5C04\uFF09");
  const notices = [];
  const attribution = buildSourceAttribution(article);
  if (attribution && settings.appendSourceLink !== false) notices.push(`\u5C06\u5728\u6B63\u6587\u672B\u5C3E\u6CE8\u5165\u9996\u53D1\u58F0\u660E\uFF08\u6398\u91D1\u539F\u6587\uFF1A${article.sourceUrl}\uFF09`);
  return {
    titleLength: title.length,
    contentLength: markdown.length,
    summaryPreview: settings.autoSummary === false ? "" : article.summary?.trim() || extractSummary(markdown),
    categories,
    imageCount: images.length,
    images: images.slice(0, 20),
    containerCount: countJuejinContainers(rawMarkdown),
    codeFenceCount: countCodeFences(markdown),
    issues,
    notices
  };
}

// src/types.ts
var uid = () => crypto.randomUUID();

// src/background.ts
var runningTasks = /* @__PURE__ */ new Set();
var taskGate = new Semaphore(2);
var JUEJIN_UUID_KEY = "juejinUuid";
async function getJuejinUuid() {
  return (await chrome.storage.local.get(JUEJIN_UUID_KEY))[JUEJIN_UUID_KEY] || "";
}
async function ensureArticleContent(article) {
  if (article.markdown.trim().length >= 20) return article;
  const uuid = await getJuejinUuid();
  if (!uuid) throw new SyncError("\u672C\u5730\u5DF2\u6E05\u7406\u6587\u7AE0\u6B63\u6587\uFF0C\u8BF7\u5148\u6253\u5F00\u6398\u91D1\u4EFB\u610F\u9875\u9762\u540E\u91CD\u8BD5", "unknown", "validation");
  if (article.sourceDraftId) {
    const fetched = await fetchJuejinDraftByDraftId(article.sourceDraftId, uuid, article.title);
    return { ...fetched, id: article.id, sourceUrl: article.sourceUrl };
  }
  if (/^\d+$/.test(article.id)) {
    const fetched = await fetchJuejinDraftByArticleId(article.id, uuid, article.title);
    return { ...fetched, sourceUrl: article.sourceUrl || fetched.sourceUrl };
  }
  throw new SyncError("\u6587\u7AE0\u6B63\u6587\u5DF2\u6E05\u7406\u4E14\u7F3A\u5C11\u6398\u91D1\u8349\u7A3F\u6807\u8BC6\uFF0C\u8BF7\u4ECE\u6398\u91D1\u9875\u9762\u91CD\u65B0\u53D1\u8D77\u540C\u6B65", "content", "validation");
}
async function runTask(task) {
  const startedAt = Date.now();
  let stage = "validation";
  try {
    const article = await ensureArticleContent(task.article);
    validateCsdnArticle(article);
    const settings = await getSettings();
    await patchTask(task.id, { status: "checking-login", attempts: task.attempts + 1, error: void 0, diagnostic: void 0, warnings: void 0, stats: void 0, progress: { current: 0, total: 0, message: "\u6B63\u5728\u68C0\u67E5 CSDN \u767B\u5F55\u72B6\u6001" } });
    const transformed = csdnAdapter.transform(article);
    await patchTask(task.id, { status: "transforming", progress: { current: 0, total: 0, message: "\u6B63\u5728\u5904\u7406\u6587\u7AE0\u5185\u5BB9" } });
    stage = "authentication";
    if (task.csdnArticleId) {
      const state = await fetchCsdnArticleState(task.csdnArticleId);
      if (state === "published") throw new SyncError("\u8BE5 CSDN \u6587\u7AE0\u5DF2\u516C\u5F00\u53D1\u5E03\uFF0C\u4E3A\u907F\u514D\u8986\u76D6\u7EBF\u4E0A\u6587\u7AE0\u5DF2\u963B\u65AD\u540C\u6B65\u3002\u5982\u9700\u7EE7\u7EED\uFF0C\u8BF7\u5220\u9664\u672C\u6761\u540C\u6B65\u8BB0\u5F55\u540E\u53E6\u5B58\u65B0\u8349\u7A3F\u3002", "blocked", "draft");
    }
    const result = await saveDraftViaApi(transformed, {
      articleId: task.csdnArticleId,
      categories: resolveCsdnCategories(transformed.tags, settings),
      syncCover: settings.syncCover,
      autoSummary: settings.autoSummary,
      appendSourceLink: settings.appendSourceLink,
      imageFailurePolicy: settings.imageFailurePolicy,
      onPreparing: () => {
        stage = "content";
      },
      onProgress: async (progress) => {
        stage = "images";
        await patchTask(task.id, { status: "transforming", progress });
      },
      onSaving: async () => {
        stage = "draft";
        await patchTask(task.id, { status: "writing", progress: { current: 1, total: 1, message: task.csdnArticleId ? "\u6B63\u5728\u66F4\u65B0 CSDN \u8349\u7A3F" : "\u6B63\u5728\u521B\u5EFA CSDN \u8349\u7A3F" } });
      }
    });
    await patchTask(task.id, { status: "saved", draftUrl: result.draftUrl, csdnArticleId: result.articleId, warnings: result.warnings, stats: { ...result.stats, durationMs: Date.now() - startedAt }, progress: void 0 });
    await saveArticleDraftMapping(task.article, result.articleId, result.draftUrl);
    await chrome.action.setBadgeBackgroundColor({ color: "#1d6744" });
    await chrome.action.setBadgeText({ text: "\u2713" });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 5e3);
    const notification = buildTaskNotification({ ...task, status: "saved", draftUrl: result.draftUrl, stats: { ...result.stats, durationMs: Date.now() - startedAt } }, Date.now() - startedAt);
    if (notification) await showTaskNotification(notification);
  } catch (error) {
    const diagnostic = classifySyncError(error, stage);
    const failedTask = { ...task, status: diagnostic.category === "login" || diagnostic.category === "blocked" ? "needs-user" : "failed", error: diagnostic.message, diagnostic };
    await patchTask(task.id, { status: failedTask.status, error: diagnostic.message, diagnostic, progress: void 0 });
    await chrome.action.setBadgeBackgroundColor({ color: "#a24332" });
    await chrome.action.setBadgeText({ text: "!" });
    const notification = buildTaskNotification(failedTask, Date.now() - startedAt);
    if (notification) await showTaskNotification(notification);
    throw error;
  }
}
async function execute(task) {
  if (runningTasks.has(task.id)) return;
  runningTasks.add(task.id);
  try {
    await taskGate.run(() => runTask(task));
  } finally {
    runningTasks.delete(task.id);
  }
}
async function create(article) {
  const tasks = await allTasks();
  const previous = findMatchingTask(tasks, article);
  const active = previous && isActiveTask(previous) ? previous : void 0;
  if (active) return active;
  const settings = await getSettings();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const mapping = previous ? void 0 : await getArticleDraftMapping(article);
  const csdnArticleId = previous?.csdnArticleId || extractCsdnArticleId(previous?.draftUrl) || mapping?.csdnArticleId;
  const draftUrl = previous?.draftUrl || mapping?.draftUrl;
  const needsConfirmation = shouldConfirmDraftUpdate(settings, csdnArticleId);
  const task = previous ? { ...previous, article, status: needsConfirmation ? "needs-confirmation" : "queued", updatedAt: now, csdnArticleId, error: void 0, diagnostic: void 0, warnings: void 0, stats: void 0, progress: void 0 } : { id: uid(), article, platform: "csdn", status: needsConfirmation ? "needs-confirmation" : "queued", createdAt: now, updatedAt: now, attempts: 0, csdnArticleId, draftUrl };
  await putTask(task);
  if (needsConfirmation) return task;
  await execute(task);
  return (await allTasks()).find((item) => item.id === task.id) || task;
}
async function recoverInterruptedTasks() {
  const tasks = await allTasks();
  const uncertain = tasks.filter(isUncertainCreateTask);
  await Promise.all(uncertain.map((task) => patchTask(task.id, {
    status: "needs-user",
    error: "\u4E0A\u6B21\u521B\u5EFA CSDN \u8349\u7A3F\u65F6\u6269\u5C55\u88AB\u4E2D\u65AD\uFF0C\u65E0\u6CD5\u786E\u8BA4\u662F\u5426\u5DF2\u4FDD\u5B58\u3002\u8BF7\u5148\u68C0\u67E5 CSDN \u8349\u7A3F\u7BB1\uFF0C\u518D\u51B3\u5B9A\u662F\u5426\u91CD\u8BD5\u3002",
    diagnostic: classifySyncError(new Error("\u4E0A\u6B21\u521B\u5EFA CSDN \u8349\u7A3F\u65F6\u6269\u5C55\u88AB\u4E2D\u65AD\uFF0C\u65E0\u6CD5\u786E\u8BA4\u662F\u5426\u5DF2\u4FDD\u5B58\u3002"), "recovery"),
    progress: void 0
  })));
  const interrupted = tasks.filter(isInterruptedTask);
  await Promise.allSettled(interrupted.map((task) => execute(task)));
}
var recovery = migrateStoredTasks().then(() => recoverInterruptedTasks());
async function openCsdnLogin() {
  await chrome.tabs.create({ url: "https://passport.csdn.net/login", active: true });
}
async function syncHistory(request) {
  if (request.uuid) await chrome.storage.local.set({ [JUEJIN_UUID_KEY]: request.uuid });
  const auth = await checkCsdnAuth();
  if (!auth.ok) throw new Error(auth.message || "CSDN \u767B\u5F55\u72B6\u6001\u68C0\u6D4B\u5931\u8D25");
  if (!auth.loggedIn) {
    await chrome.storage.session.set({ pendingHistory: { ...request, expiresAt: Date.now() + 10 * 60 * 1e3 } });
    await openCsdnLogin();
    return { ok: false, needsLogin: true, message: "\u8BF7\u5148\u767B\u5F55 CSDN\uFF0C\u8FD4\u56DE\u6398\u91D1\u540E\u5C06\u7EE7\u7EED\u540C\u6B65" };
  }
  const article = await fetchJuejinDraftByArticleId(request.articleId, request.uuid, request.title);
  const previous = findMatchingTask(await allTasks(), article);
  const mapping = previous ? void 0 : await getArticleDraftMapping(article);
  const updated = !!(previous?.csdnArticleId || extractCsdnArticleId(previous?.draftUrl) || mapping?.csdnArticleId);
  return { ok: true, articleId: request.articleId, updated, task: await create(article) };
}
async function resumePendingHistory() {
  const { pendingHistory } = await chrome.storage.session.get("pendingHistory");
  if (!pendingHistory || pendingHistory.expiresAt <= Date.now()) {
    await chrome.storage.session.remove("pendingHistory");
    return { ok: true, resumed: false };
  }
  const auth = await checkCsdnAuth();
  if (!auth.ok) throw new Error(auth.message || "CSDN \u767B\u5F55\u72B6\u6001\u68C0\u6D4B\u5931\u8D25");
  if (!auth.loggedIn) return { ok: true, resumed: false, needsLogin: true };
  await chrome.storage.session.remove("pendingHistory");
  const article = await fetchJuejinDraftByArticleId(pendingHistory.articleId, pendingHistory.uuid, pendingHistory.title);
  return { ok: true, resumed: true, articleId: pendingHistory.articleId, task: await create(article) };
}
async function dryRunTask(id) {
  const task = (await allTasks()).find((item) => item.id === id);
  if (!task) return { ok: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" };
  try {
    const article = await ensureArticleContent(task.article);
    const settings = await getSettings();
    return { ok: true, report: buildDryRunReport(article, settings) };
  } catch (error) {
    return { ok: false, message: error.message || "\u9884\u6F14\u5931\u8D25" };
  }
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  (async () => {
    if (!isSupportedMessage(message)) {
      reply({ ok: false, message: "\u4E0D\u652F\u6301\u7684\u6269\u5C55\u6D88\u606F" });
      return;
    }
    await recovery;
    if (message.type === "SYNC_NEW_ARTICLE") {
      reply({ ok: true, task: await create(message.article) });
    } else if (message.type === "CHECK_CSDN_STATUS") {
      reply(await checkCsdnAuth());
    } else if (message.type === "OPEN_CSDN_LOGIN") {
      await openCsdnLogin();
      reply({ ok: true });
    } else if (message.type === "REPORT_JUEJIN_UUID") {
      const uuid = String(message.uuid || "");
      if (uuid) await chrome.storage.local.set({ [JUEJIN_UUID_KEY]: uuid });
      reply({ ok: true });
    } else if (message.type === "SYNC_HISTORY_ARTICLE") {
      reply(await syncHistory({ articleId: String(message.articleId), title: String(message.title || ""), sourceUrl: String(message.sourceUrl || ""), uuid: String(message.uuid || "") }));
    } else if (message.type === "RESUME_PENDING_HISTORY") {
      reply(await resumePendingHistory());
    } else if (message.type === "GET_TASKS") {
      reply({ ok: true, tasks: await allTasks() });
    } else if (message.type === "GET_SETTINGS") {
      reply({ ok: true, settings: await getSettings() });
    } else if (message.type === "SAVE_SETTINGS") {
      await saveSettings(message.settings);
      reply({ ok: true });
    } else if (message.type === "RETRY_TASK") {
      const task = (await allTasks()).find((item) => item.id === message.id);
      if (task) {
        void execute(task).catch(() => {
        });
        reply({ ok: true });
      } else reply({ ok: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" });
    } else if (message.type === "CONFIRM_TASK_UPDATE") {
      const task = (await allTasks()).find((item) => item.id === message.id);
      if (!task) {
        reply({ ok: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" });
      } else if (task.status !== "needs-confirmation") {
        reply({ ok: false, message: "\u4EFB\u52A1\u4E0D\u9700\u8981\u786E\u8BA4" });
      } else {
        void execute(task).catch(() => {
        });
        reply({ ok: true });
      }
    } else if (message.type === "RETRY_FAILED_TASKS") {
      const tasks = (await allTasks()).filter(isRetryableTask);
      tasks.forEach((task) => void execute(task).catch(() => {
      }));
      reply({ ok: true, count: tasks.length });
    } else if (message.type === "DELETE_TASK") {
      const task = (await allTasks()).find((item) => item.id === message.id);
      if (!task) {
        reply({ ok: false, message: "\u4EFB\u52A1\u4E0D\u5B58\u5728" });
      } else if (runningTasks.has(task.id) || !canDeleteTask(task)) {
        reply({ ok: false, message: "\u8FDB\u884C\u4E2D\u7684\u4EFB\u52A1\u4E0D\u80FD\u5220\u9664" });
      } else {
        await deleteTask(task.id);
        reply({ ok: true });
      }
    } else if (message.type === "CLEAR_TASKS") {
      await clearAllTasks();
      reply({ ok: true });
    } else if (message.type === "FETCH_CSDN_CATEGORIES") {
      reply(await fetchCsdnCategories());
    } else if (message.type === "DRY_RUN_TASK") {
      reply(await dryRunTask(String(message.id)));
    } else if (message.type === "GET_HEALTH_STATUS") {
      const status = await getCachedHealth();
      reply({ ok: true, status, alert: isHealthAlert(status) });
    }
  })().catch((error) => reply({ ok: false, message: error.message }));
  return true;
});
chrome.notifications?.onClicked?.addListener((notificationId) => {
  void (async () => {
    try {
      const tasks = await allTasks();
      const task = tasks.find((item) => item.id === notificationId);
      await chrome.notifications.clear(notificationId).catch(() => {
      });
      if (task?.draftUrl) await chrome.tabs.create({ url: task.draftUrl, active: true });
      else await chrome.tabs.create({ url: chrome.runtime.getURL("popup.html"), active: true });
    } catch {
    }
  })();
});
try {
  void (async () => {
    try {
      if (!await chrome.alarms.get(HEALTH_CHECK_ALARM)) await chrome.alarms.create(HEALTH_CHECK_ALARM, { periodInMinutes: 720 });
    } catch {
    }
  })();
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === HEALTH_CHECK_ALARM) void refreshHealthIfNeeded(true);
  });
  void refreshHealthIfNeeded();
} catch {
}
