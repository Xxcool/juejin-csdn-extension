// src/juejin-page.ts
var READ_EDITOR_EVENT = "article-ferry:read-editor";
var SNAPSHOT_ATTRIBUTE = "data-article-ferry-editor";
var DRAFT_TAG_ENDPOINT = /article_draft\/(?:save|detail)/;
var cachedTags = [];
function rememberTags(url, text) {
  if (!DRAFT_TAG_ENDPOINT.test(url)) return;
  try {
    const draft = JSON.parse(text);
    const tags = draft.data?.article_draft?.tags || draft.data?.tags;
    if (Array.isArray(tags)) cachedTags = tags.map((tag) => tag?.tag_name || "").filter(Boolean);
  } catch {
  }
}
function observeDraftApi() {
  if (!("__articleFerryHooked" in window)) {
    Object.defineProperty(window, "__articleFerryHooked", { value: true, enumerable: false });
    const originalFetch = window.fetch.bind(window);
    window.fetch = async (input, init) => {
      const response = await originalFetch(input, init);
      try {
        const url = input instanceof Request ? input.url : String(input);
        if (DRAFT_TAG_ENDPOINT.test(url)) rememberTags(url, await response.clone().text());
      } catch {
      }
      return response;
    };
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__ferryUrl = String(url);
      return originalOpen.apply(this, [method, url, ...rest]);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      this.addEventListener("load", () => {
        try {
          rememberTags(this.__ferryUrl || "", this.responseText);
        } catch {
        }
      });
      return originalSend.apply(this, args);
    };
  }
}
function editorSnapshot() {
  const titleInput = document.querySelector('input[placeholder*="\u6587\u7AE0\u6807\u9898"],textarea[placeholder*="\u6587\u7AE0\u6807\u9898"]');
  const codeMirror = document.querySelector(".CodeMirror")?.CodeMirror;
  const textarea = document.querySelector(".CodeMirror textarea,textarea.bytemd-hidden");
  const markdown = codeMirror?.getValue() || textarea?.value || "";
  const draftId = location.pathname.match(/\/editor\/drafts\/(\d+)/)?.[1] || "";
  return { title: titleInput?.value.trim() || "", markdown, draftId, sourceUrl: location.href, tags: cachedTags };
}
observeDraftApi();
document.addEventListener(READ_EDITOR_EVENT, () => {
  document.documentElement.setAttribute(SNAPSHOT_ATTRIBUTE, JSON.stringify(editorSnapshot()));
});
