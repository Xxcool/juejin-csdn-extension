// src/source/juejin-api.ts
function extractArticleId(url) {
  return url.match(/\/post\/(\d+)/)?.[1] || null;
}

// src/juejin-content.ts
var READ_EDITOR_EVENT = "article-ferry:read-editor";
var SNAPSHOT_ATTRIBUTE = "data-article-ferry-editor";
var HISTORY_SYNC_ICON = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 5.5A5.5 5.5 0 0 0 3.2 4L2 5.5M3 10.5A5.5 5.5 0 0 0 12.8 12l1.2-1.5M2 2.8V5.5h2.7M14 13.2v-2.7h-2.7"/></svg>';
var autoDefault = true;
var syncEnabled = false;
var loginState = "checking";
var loginCheckSequence = 0;
var wiredButtons = /* @__PURE__ */ new WeakSet();
function getNewEditorContext() {
  const rightBox = document.querySelector(".right-box");
  if (!rightBox) return null;
  const publishPopup = rightBox.querySelector(".publish-popup");
  const actionButton = publishPopup?.querySelector(":scope > button");
  const actionText = actionButton?.innerText.trim() || "";
  if (!/发布/.test(actionText) || /更新/.test(actionText)) return null;
  const draftButton = [...rightBox.querySelectorAll(":scope > button")].find((button) => button.classList.contains("btn-drafts") || /草稿箱/.test(button.innerText));
  return draftButton ? { rightBox, publishPopup, draftButton } : null;
}
function readSelectedTagsFromDom() {
  const popup = document.querySelector(".publish-popup");
  if (!popup) return [];
  const tags = [...popup.querySelectorAll('[class*="tag"]')].filter((element) => typeof element.className === "string" && /(?:^|[-\s])(?:active|selected|checked)(?:[-\s]|$)/i.test(element.className)).filter((element) => !element.querySelector('[class*="tag"]')).map((element) => element.textContent?.trim() || "").filter((text) => text.length >= 1 && text.length <= 30);
  return [...new Set(tags)];
}
function readEditorArticle() {
  document.documentElement.removeAttribute(SNAPSHOT_ATTRIBUTE);
  document.dispatchEvent(new Event(READ_EDITOR_EVENT));
  const raw = document.documentElement.getAttribute(SNAPSHOT_ATTRIBUTE);
  document.documentElement.removeAttribute(SNAPSHOT_ATTRIBUTE);
  if (!raw) throw new Error("\u65E0\u6CD5\u8FDE\u63A5\u6398\u91D1\u7F16\u8F91\u5668");
  const snapshot = JSON.parse(raw);
  if (snapshot.title.trim().length < 2 || snapshot.markdown.trim().length < 20) throw new Error("\u6587\u7AE0\u6807\u9898\u6216\u6B63\u6587\u4E0D\u5B8C\u6574");
  return {
    id: snapshot.draftId || `draft-${Date.now()}`,
    sourceDraftId: snapshot.draftId || void 0,
    title: snapshot.title.trim(),
    markdown: snapshot.markdown,
    tags: snapshot.tags?.length ? snapshot.tags : readSelectedTagsFromDom(),
    sourceUrl: snapshot.sourceUrl
  };
}
function showSyncError(message) {
  const hint = document.querySelector(".jc-sync-option small");
  if (hint) hint.textContent = `\u540C\u6B65\u672A\u542F\u52A8\uFF1A${message}`;
}
function wireFinalPublish(panel) {
  const button = [...panel.querySelectorAll(".footer button,button")].find((element) => /确定并发布/.test(element.innerText));
  if (!button || wiredButtons.has(button)) return;
  wiredButtons.add(button);
  button.addEventListener("click", () => {
    if (!syncEnabled) return;
    try {
      const article = readEditorArticle();
      chrome.runtime.sendMessage({ type: "SYNC_NEW_ARTICLE", article }).then((result) => {
        if (!result?.ok) showSyncError(result?.message || "\u540C\u6B65\u5931\u8D25");
      }).catch((error) => showSyncError(error.message));
    } catch (error) {
      showSyncError(error.message);
    }
  }, true);
}
function renderLoginState() {
  const option = document.querySelector(".jc-sync-option");
  const input = option?.querySelector("input");
  const hint = option?.querySelector("small");
  if (!option || !input || !hint) return;
  if (loginState === "logged-in") {
    input.disabled = false;
    if (!option.dataset.initialized) {
      input.checked = autoDefault;
      option.dataset.initialized = "true";
    }
    syncEnabled = input.checked;
    hint.textContent = "\u5DF2\u5C31\u7EEA\uFF0C\u53D1\u5E03\u65F6\u4FDD\u5B58\u4E3A\u8349\u7A3F";
  } else {
    input.checked = false;
    input.disabled = true;
    syncEnabled = false;
    hint.textContent = loginState === "checking" ? "\u68C0\u6D4B CSDN \u767B\u5F55\u72B6\u6001\u2026" : loginState === "logged-out" ? "\u70B9\u51FB\u767B\u5F55 CSDN" : "\u72B6\u6001\u68C0\u6D4B\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5";
  }
}
async function updateCsdnState() {
  if (!document.querySelector(".jc-sync-option")) return;
  const sequence = ++loginCheckSequence;
  loginState = "checking";
  renderLoginState();
  try {
    const result = await chrome.runtime.sendMessage({ type: "CHECK_CSDN_STATUS" });
    if (sequence !== loginCheckSequence) return;
    loginState = result?.loggedIn ? "logged-in" : result?.ok ? "logged-out" : "error";
  } catch {
    if (sequence !== loginCheckSequence) return;
    loginState = "error";
  }
  renderLoginState();
}
function createNewArticleOption() {
  const option = document.createElement("label");
  option.className = "jc-sync-option jc-editor-sync-control";
  option.innerHTML = '<input type="checkbox"><span class="jc-check">\u2713</span><span class="jc-sync-copy"><b>\u540C\u6B65\u5230 CSDN \u8349\u7A3F</b><small>\u68C0\u6D4B CSDN \u767B\u5F55\u72B6\u6001\u2026</small></span>';
  const input = option.querySelector("input");
  input.addEventListener("change", () => syncEnabled = input.checked);
  option.addEventListener("click", () => {
    if (loginState === "logged-out") void chrome.runtime.sendMessage({ type: "OPEN_CSDN_LOGIN" });
    else if (loginState === "error") void updateCsdnState();
  });
  return option;
}
function injectEditorIntegration() {
  const context = getNewEditorContext();
  if (!context) {
    document.querySelectorAll(".jc-editor-sync-control").forEach((element) => element.remove());
    syncEnabled = false;
    return;
  }
  let control = context.rightBox.querySelector(":scope > .jc-editor-sync-control");
  if (!control) {
    control = createNewArticleOption();
    context.rightBox.insertBefore(control, context.draftButton);
    updateCsdnState();
  }
  const panel = context.publishPopup?.querySelector(".panel");
  if (panel) wireFinalPublish(panel);
}
function getJuejinUuid() {
  for (const entry of performance.getEntriesByType("resource")) {
    try {
      const url = new URL(entry.name);
      const uuid = url.searchParams.get("uuid");
      if (url.hostname === "api.juejin.cn" && uuid) return uuid;
    } catch {
    }
  }
  return "";
}
function setHistoryButtonState(button, state, message = "") {
  button.dataset.state = state;
  const label = button.querySelector(".jc-history-label");
  if (label) label.textContent = state === "working" ? "\u6B63\u5728\u540C\u6B65\u2026" : state === "login" ? "\u767B\u5F55\u540E\u7EE7\u7EED\u540C\u6B65" : state === "saved" ? "\u5DF2\u4FDD\u5B58\u5230 CSDN \u2713" : state === "updated" ? "\u5DF2\u66F4\u65B0 CSDN \u8349\u7A3F \u2713" : message || "\u540C\u6B65\u5230 CSDN";
}
async function syncHistoryArticle(button) {
  if (button.dataset.state === "working") return;
  setHistoryButtonState(button, "working");
  const articleId = button.dataset.articleId;
  try {
    const result = await chrome.runtime.sendMessage({
      type: "SYNC_HISTORY_ARTICLE",
      articleId,
      title: button.dataset.title || "",
      sourceUrl: `https://juejin.cn/post/${articleId}`,
      uuid: getJuejinUuid()
    });
    if (result?.needsLogin) {
      setHistoryButtonState(button, "login");
      return;
    }
    if (!result?.ok) throw new Error(result?.message || "\u540C\u6B65\u5931\u8D25");
    setHistoryButtonState(button, result.updated ? "updated" : "saved");
    rememberSynced(articleId);
  } catch (error) {
    setHistoryButtonState(button, "idle");
    alert(`\u6587\u7AE0\u6446\u6E21\uFF1A${error.message}`);
  }
}
var syncedIds;
function syncedArticleIds() {
  if (!syncedIds) {
    try {
      syncedIds = chrome.runtime.sendMessage({ type: "GET_TASKS" }).then((result) => {
        const ids = /* @__PURE__ */ new Set();
        for (const task of result?.tasks || []) {
          if (task.status !== "saved") continue;
          if (task.article?.id) ids.add(task.article.id);
          const sourceId = task.article?.sourceUrl ? extractArticleId(task.article.sourceUrl) : "";
          if (sourceId) ids.add(sourceId);
        }
        return ids;
      }).catch(() => {
        syncedIds = void 0;
        return /* @__PURE__ */ new Set();
      });
    } catch {
      return Promise.resolve(/* @__PURE__ */ new Set());
    }
  }
  return syncedIds;
}
function rememberSynced(articleId) {
  void syncedArticleIds().then((ids) => ids.add(articleId));
}
async function markSyncedButtons() {
  const buttons = document.querySelectorAll(".jc-history-sync,.jc-creator-sync");
  if (!buttons.length) return;
  const ids = await syncedArticleIds();
  buttons.forEach((button) => {
    if (button.dataset.state === "idle" && ids.has(button.dataset.articleId || "")) setHistoryButtonState(button, "saved");
  });
}
function injectHistoryMenus() {
  document.querySelectorAll(".content-main li.item.more > ul.more-list").forEach((menu) => {
    if (menu.querySelector(".jc-history-sync")) return;
    const menuText = menu.innerText;
    if (!/编辑/.test(menuText) || !/删除/.test(menuText)) return;
    const content = menu.closest(".content-main");
    const link = content?.querySelector('a[href^="/post/"]');
    const articleId = link ? extractArticleId(link.href) : null;
    if (!articleId) return;
    const item = document.createElement("li");
    item.className = "item jc-history-sync";
    item.dataset.articleId = articleId;
    item.dataset.title = link?.getAttribute("title") || link?.textContent?.trim() || "";
    item.dataset.state = "idle";
    item.innerHTML = `${HISTORY_SYNC_ICON}<span class="jc-history-label">\u540C\u6B65\u5230 CSDN</span>`;
    item.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void syncHistoryArticle(item);
    });
    const deleteItem = menu.querySelector(":scope > li.delete");
    menu.insertBefore(item, deleteItem);
  });
}
function injectCreatorCenterSync() {
  if (!location.pathname.startsWith("/creator/content/article")) return;
  document.querySelectorAll(".byte-dropdown").forEach((dropdown) => {
    const cell = dropdown.parentElement;
    if (!cell || cell.querySelector(".jc-creator-sync")) return;
    let row = dropdown;
    let link = null;
    while (row && row !== document.body) {
      if (row.querySelectorAll(".byte-dropdown").length > 1) break;
      if (row instanceof HTMLAnchorElement && row.href.includes("/post/")) {
        link = row;
        break;
      }
      link = row.querySelector('a[href*="/post/"]');
      if (link) break;
      row = row.parentElement;
    }
    if (!link) return;
    const articleId = extractArticleId(link.href);
    if (!articleId) return;
    const title = link.getAttribute("title") || link.querySelector(".title")?.textContent?.trim() || "";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "jc-creator-sync";
    button.dataset.articleId = articleId;
    if (title) button.dataset.title = title;
    button.dataset.state = "idle";
    button.title = "\u540C\u6B65\u5230 CSDN \u8349\u7A3F\u7BB1";
    button.innerHTML = `${HISTORY_SYNC_ICON}<span class="jc-history-label">\u540C\u6B65\u5230 CSDN</span>`;
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void syncHistoryArticle(button);
    });
    cell.insertBefore(button, dropdown);
  });
}
async function resumePendingHistory() {
  try {
    const result = await chrome.runtime.sendMessage({ type: "RESUME_PENDING_HISTORY" });
    if (!result?.ok) {
      if (result?.message) alert(`\u6587\u7AE0\u6446\u6E21\uFF1A${result.message}`);
      return;
    }
    if (!result.resumed) return;
    const button = [...document.querySelectorAll(".jc-history-sync,.jc-creator-sync")].find((item) => item.dataset.articleId === String(result.articleId));
    if (button) {
      setHistoryButtonState(button, "saved");
      rememberSynced(String(result.articleId));
    }
  } catch {
  }
}
function inject() {
  injectEditorIntegration();
  injectHistoryMenus();
  injectCreatorCenterSync();
  void markSyncedButtons();
}
var injectScheduled = false;
function scheduleInject() {
  if (injectScheduled) return;
  injectScheduled = true;
  requestAnimationFrame(() => {
    injectScheduled = false;
    inject();
  });
}
function reportJuejinUuid() {
  const uuid = getJuejinUuid();
  if (uuid) void chrome.runtime.sendMessage({ type: "REPORT_JUEJIN_UUID", uuid }).catch(() => {
  });
}
chrome.runtime.sendMessage({ type: "GET_SETTINGS" }).then((result) => {
  autoDefault = result?.settings?.autoSyncAfterPublish !== false;
  reportJuejinUuid();
  inject();
  new MutationObserver(scheduleInject).observe(document.documentElement, { childList: true, subtree: true });
});
window.addEventListener("focus", () => {
  reportJuejinUuid();
  void updateCsdnState();
  void resumePendingHistory();
  syncedIds = void 0;
  void markSyncedButtons();
});
